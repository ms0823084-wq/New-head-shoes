package com.example.ai

import com.example.data.AiCoachInsight
import com.example.data.SensitivityProfile
import com.example.data.TrainingSession
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object HeadshotCoachEngine {

    /**
     * Generates a tailored Free Fire & Free Fire MAX sensitivity configuration.
     * Incorporates phone specs, refresh rate, FPS, finger ergonomics, and playstyle.
     */
    fun generateSensitivity(
        gameVersion: String,
        phoneModel: String,
        fpsSetting: String,
        refreshRateHz: Int,
        fingerLayout: String,
        playstyle: String
    ): SensitivityProfile {
        // Base starting values for optimal Free Fire drag physics
        var general = 95
        var redDot = 88
        var scope2x = 82
        var scope4x = 75
        var sniper = 50
        var freeLook = 72
        var buttonSize = 48
        var dpi = 411

        // 1. Game version adjustment: MAX has slightly different acceleration curve
        if (gameVersion.contains("MAX", ignoreCase = true)) {
            general += 2
            redDot += 2
            scope2x += 1
        }

        // 2. Screen refresh rate & FPS physics
        when {
            refreshRateHz >= 120 || fpsSetting.contains("120") || fpsSetting.contains("Ultra") -> {
                // High refresh rate allows precise drag control without over-acceleration
                general -= 2
                redDot -= 2
                dpi = 460
            }
            refreshRateHz <= 60 || fpsSetting.contains("30") || fpsSetting.contains("Normal") -> {
                // Lower refresh rate needs higher sensitivity to lift crosshair quickly
                general += 3
                redDot += 3
                scope2x += 2
                dpi = 392
            }
        }

        // 3. Finger layout ergonomics
        when (fingerLayout) {
            "2-Finger", "2-Finger Thumb" -> {
                // Thumbs have limited vertical reach before losing grip
                general = min(100, general + 2)
                buttonSize = 46 // Smaller button gives more room to drag upward
            }
            "3-Finger Claw" -> {
                buttonSize = 50
                redDot = max(75, redDot - 1)
            }
            "4-Finger Claw" -> {
                // Full claw allows controlled long drag strokes
                general = max(88, general - 2)
                redDot = max(82, redDot - 2)
                buttonSize = 52
                dpi = 440
            }
        }

        // 4. Playstyle specializations
        when (playstyle) {
            "One-Tap / Rusher" -> {
                general = min(100, general + 3)
                redDot = min(100, redDot + 4)
                buttonSize = 45 // Classic M1887 / Desert Eagle drag size
            }
            "Sniper" -> {
                general = max(88, general - 3)
                sniper = 56
                scope4x = 78
                buttonSize = 52
            }
            "All-Rounder" -> {
                // Standard balanced profile
            }
        }

        // Clamp values to safe Free Fire slider boundaries (0 to 100)
        general = general.coerceIn(85, 100)
        redDot = redDot.coerceIn(75, 100)
        scope2x = scope2x.coerceIn(65, 95)
        scope4x = scope4x.coerceIn(55, 90)
        sniper = sniper.coerceIn(35, 70)
        freeLook = freeLook.coerceIn(50, 90)
        buttonSize = buttonSize.coerceIn(40, 60)

        val profileName = "$gameVersion $playstyle ($fingerLayout)"

        return SensitivityProfile(
            profileName = profileName,
            gameVersion = gameVersion,
            phoneModel = phoneModel.ifBlank { "Android Device" },
            fpsSetting = fpsSetting,
            refreshRateHz = refreshRateHz,
            fingerLayout = fingerLayout,
            generalSens = general,
            redDotSens = redDot,
            scope2xSens = scope2x,
            scope4xSens = scope4x,
            sniperSens = sniper,
            freeLookSens = freeLook,
            fireButtonSize = buttonSize,
            fireButtonPosition = "Lower Right Corner (32% from right, 18% from bottom)",
            dpiRecommendation = dpi,
            playstyle = playstyle,
            isDefault = true
        )
    }

    /**
     * Calculates the genuine Headshot Improvement Score (0-100)
     * derived strictly from recorded simulator sessions.
     */
    fun calculateScore(sessions: List<TrainingSession>): Int {
        if (sessions.isEmpty()) return 0

        val recent = sessions.take(10)
        var totalAccuracyScore = 0f
        var totalReactionScore = 0f
        var totalConsistencyScore = 0f

        for (s in recent) {
            // Accuracy: headshot percentage (max 40 pts)
            val accWeight = (s.headshotPercentage.coerceIn(0f, 100f) / 100f) * 40f
            totalAccuracyScore += accWeight

            // Reaction Time score (max 35 pts)
            // Benchmarks: 180ms = 35pts, 250ms = 30pts, 350ms = 20pts, 500ms = 5pts
            val reactionScore = when {
                s.avgReactionTimeMs <= 200 -> 35f
                s.avgReactionTimeMs <= 260 -> 30f
                s.avgReactionTimeMs <= 330 -> 24f
                s.avgReactionTimeMs <= 420 -> 16f
                else -> 8f
            }
            totalReactionScore += reactionScore

            // Consistency & Drag Control score (max 25 pts)
            // Penalty for overshoots and undershoots
            val erraticShots = s.overshoots + s.undershoots
            val optimalRatio = if (s.totalShots > 0) {
                (s.totalShots - erraticShots).coerceAtLeast(0).toFloat() / s.totalShots
            } else 0.5f
            val consistencyScore = optimalRatio * 25f
            totalConsistencyScore += consistencyScore
        }

        val count = recent.size.toFloat()
        val finalScore = ((totalAccuracyScore + totalReactionScore + totalConsistencyScore) / count).roundToInt()
        return finalScore.coerceIn(5, 99)
    }

    /**
     * Computes the before-and-after comparison based on actual practice data.
     */
    fun calculateBeforeAfter(
        earliestSessions: List<TrainingSession>,
        latestSessions: List<TrainingSession>
    ): Pair<Int, Int>? {
        if (earliestSessions.isEmpty() || latestSessions.isEmpty()) return null
        val baselineScore = calculateScore(earliestSessions)
        val currentScore = calculateScore(latestSessions)
        return Pair(baselineScore, currentScore)
    }

    /**
     * Diagnoses weak areas and recommends specific sensitivity adjustments.
     */
    fun analyzeSessions(
        recentSessions: List<TrainingSession>,
        activeProfile: SensitivityProfile?
    ): AiCoachInsight {
        if (recentSessions.isEmpty()) {
            return AiCoachInsight(
                title = "AI Coach Ready",
                subtitle = "No training data recorded yet",
                recommendation = "Complete your first 30-second Aim Trainer session to unlock personalized diagnostics.",
                sensitivityAdjustmentTip = "Start with the recommended General sensitivity in the Sensitivity tab.",
                suggestedDrill = "Drag Aim Headshot Drill (Close & Mid Range)",
                severity = "INFO"
            )
        }

        val sessions = recentSessions.take(5)
        var totalShots = 0
        var totalHeadshots = 0
        var totalOvershoots = 0
        var totalUndershoots = 0
        var totalReactionTime = 0L

        for (s in sessions) {
            totalShots += s.totalShots
            totalHeadshots += s.headshots
            totalOvershoots += s.overshoots
            totalUndershoots += s.undershoots
            totalReactionTime += s.avgReactionTimeMs
        }

        if (totalShots == 0) totalShots = 1
        val headshotRate = (totalHeadshots.toFloat() / totalShots) * 100f
        val overshootRate = (totalOvershoots.toFloat() / totalShots) * 100f
        val undershootRate = (totalUndershoots.toFloat() / totalShots) * 100f
        val avgReaction = totalReactionTime / sessions.size

        val currentGeneral = activeProfile?.generalSens ?: 95

        return when {
            // Case 1: Consistently overshooting above the head
            overshootRate >= 30f -> {
                val newSens = max(80, currentGeneral - 3)
                AiCoachInsight(
                    title = "Drag Overshoot Detected (${overshootRate.roundToInt()}% Shots High)",
                    subtitle = "Crosshair is flying above target head",
                    recommendation = "You are flicking the fire button with too much velocity or stopping too high. Apply a shorter, controlled upward flick instead of an aggressive swipe.",
                    sensitivityAdjustmentTip = "Decrease General Sensitivity from $currentGeneral to $newSens. Increase Fire Button size by 2% to resist over-dragging.",
                    suggestedDrill = "Mid-Range Drag Precision (Focus on stopping crosshair right at chin level)",
                    severity = "WARNING"
                )
            }

            // Case 2: Consistently undershooting (stuck on body)
            undershootRate >= 35f -> {
                val newSens = min(100, currentGeneral + 4)
                AiCoachInsight(
                    title = "Stuck on Body Shots (${undershootRate.roundToInt()}% Undershoots)",
                    subtitle = "Aim assist lock preventing headshot reach",
                    recommendation = "Your drag upward is stalling before reaching head height. In Free Fire, default aim assist pulls the crosshair into the enemy chest; you must drag with explosive initial burst.",
                    sensitivityAdjustmentTip = "Increase General Sensitivity from $currentGeneral to $newSens. Reduce Fire Button size to 45% and place it lower on your screen to allow longer upward drag stroke.",
                    suggestedDrill = "Fast Drag Aim Drill (Close Range J-Drag practice)",
                    severity = "WARNING"
                )
            }

            // Case 3: Slow reaction time
            avgReaction > 360 -> {
                AiCoachInsight(
                    title = "Reaction Speed Optimization Needed",
                    subtitle = "Average reaction time is ${avgReaction}ms",
                    recommendation = "Your drag path is decent, but target acquisition delay allows enemies to shoot first. Keep your resting crosshair higher at neck level (pre-aiming).",
                    sensitivityAdjustmentTip = "Keep current sensitivity steady. Train muscle memory on unexpected targets.",
                    suggestedDrill = "Reaction Time Reflex Drill (Beginner to Intermediate)",
                    severity = "INFO"
                )
            }

            // Case 4: High performance mastery
            headshotRate >= 65f -> {
                AiCoachInsight(
                    title = "Pro Headshot Mastery (${headshotRate.roundToInt()}% Headshot Rate)",
                    subtitle = "Consistent head-level drag control",
                    recommendation = "Excellent consistency and upward drag flick control! You have mastered stationary and linear targets.",
                    sensitivityAdjustmentTip = "Current configuration ($currentGeneral General) is well-calibrated to your phone touch sample rate. Avoid changing settings.",
                    suggestedDrill = "Advanced Moving Strafe & Zig-Zag Tracking Drill",
                    severity = "SUCCESS"
                )
            }

            // Case 5: Balanced progress
            else -> {
                AiCoachInsight(
                    title = "Solid Drag Progress (${headshotRate.roundToInt()}% Headshots)",
                    subtitle = "Reaction: ${avgReaction}ms • Steady Aim",
                    recommendation = "Focus on the white-to-red crosshair rule: keep crosshair near the target shoulder before starting your drag upward.",
                    sensitivityAdjustmentTip = "Maintain your current General sensitivity ($currentGeneral) for at least 3 consecutive days to build muscle memory.",
                    suggestedDrill = "Daily 5-Minute Warmup Routine",
                    severity = "INFO"
                )
            }
        }
    }
}
