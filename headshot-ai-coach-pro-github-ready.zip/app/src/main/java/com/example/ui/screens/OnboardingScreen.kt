package com.example.ui.screens

import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeviceUnknown
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SensitivityProfile
import com.example.ui.CoachViewModel
import com.example.ui.components.GamingCard
import com.example.ui.components.NeonButton
import com.example.ui.components.SafetyBadge
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonOrange
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
fun OnboardingScreen(
    viewModel: CoachViewModel,
    modifier: Modifier = Modifier
) {
    var step by remember { mutableIntStateOf(1) }

    // User selections
    var selectedGameVersion by remember { mutableStateOf("Free Fire MAX") }
    var phoneModel by remember {
        mutableStateOf("${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}")
    }
    var selectedFps by remember { mutableStateOf("High 60 FPS") }
    var selectedRefreshRate by remember { mutableIntStateOf(90) }
    var selectedFingerLayout by remember { mutableStateOf("2-Finger") }
    var currentSensValue by remember { mutableIntStateOf(95) }
    var selectedPlaystyle by remember { mutableStateOf("All-Rounder") }

    var generatedProfile by remember { mutableStateOf<SensitivityProfile?>(null) }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(horizontal = 20.dp, vertical = 16.dp)
            .verticalScroll(scrollState),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Progress indicators
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            for (i in 1..4) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                i < step -> NeonGreen
                                i == step -> NeonOrange
                                else -> DarkSurfaceElevated
                            }
                        )
                        .border(
                            1.dp,
                            if (i == step) NeonOrange else DarkSurfaceBorder,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (i < step) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(18.dp)
                        )
                    } else {
                        Text(
                            text = i.toString(),
                            fontWeight = FontWeight.Bold,
                            color = if (i == step) Color.Black else TextSecondary,
                            fontSize = 14.sp
                        )
                    }
                }
                if (i < 4) {
                    Box(
                        modifier = Modifier
                            .width(36.dp)
                            .height(2.dp)
                            .align(Alignment.CenterVertically)
                            .background(if (i < step) NeonGreen else DarkSurfaceBorder)
                    )
                }
            }
        }

        SafetyBadge()
        Spacer(modifier = Modifier.height(16.dp))

        // Step 1: Game Version Selection
        AnimatedVisibility(visible = step == 1) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Welcome, Survivor!",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimary
                )
                Text(
                    text = "Which Free Fire version do you play on?",
                    fontSize = 14.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    SelectableGameCard(
                        title = "Free Fire MAX",
                        subtitle = "High-res textures & smooth interpolation",
                        isSelected = selectedGameVersion == "Free Fire MAX",
                        modifier = Modifier.weight(1f)
                    ) {
                        selectedGameVersion = "Free Fire MAX"
                    }

                    SelectableGameCard(
                        title = "Free Fire (Standard)",
                        subtitle = "Classic camera acceleration & quick drag",
                        isSelected = selectedGameVersion == "Free Fire",
                        modifier = Modifier.weight(1f)
                    ) {
                        selectedGameVersion = "Free Fire"
                    }
                }

                Spacer(modifier = Modifier.height(30.dp))
                NeonButton(
                    text = "Next: Phone Specs →",
                    onClick = { step = 2 },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "onboarding_step1_next"
                )
            }
        }

        // Step 2: Phone Model & Refresh Rate
        AnimatedVisibility(visible = step == 2) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Device & Screen Hardware",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimary
                )
                Text(
                    text = "Touch sampling rate and FPS directly alter drag flick distance.",
                    fontSize = 13.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp, bottom = 18.dp)
                )

                GamingCard {
                    Column {
                        Text(
                            text = "Phone Model",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NeonOrange
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = phoneModel,
                            onValueChange = { phoneModel = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("phone_model_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedBorderColor = NeonOrange,
                                unfocusedBorderColor = DarkSurfaceBorder,
                                focusedContainerColor = DarkSurfaceElevated,
                                unfocusedContainerColor = DarkSurfaceElevated
                            ),
                            singleLine = true,
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.PhoneAndroid,
                                    contentDescription = null,
                                    tint = NeonOrange
                                )
                            }
                        )

                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Screen Refresh Rate",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NeonCyan
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(60, 90, 120, 144).forEach { hz ->
                                ChipOption(
                                    label = "${hz}Hz",
                                    isSelected = selectedRefreshRate == hz,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    selectedRefreshRate = hz
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "In-Game Graphic FPS Setting",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NeonGold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Normal 30 FPS", "High 60 FPS", "Ultra 90/120 FPS").forEach { fps ->
                                ChipOption(
                                    label = fps,
                                    isSelected = selectedFps == fps,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    selectedFps = fps
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    NeonButton(
                        text = "← Back",
                        onClick = { step = 1 },
                        isPrimary = false,
                        modifier = Modifier.weight(1f)
                    )
                    NeonButton(
                        text = "Next: Finger Layout →",
                        onClick = { step = 3 },
                        modifier = Modifier.weight(1.5f),
                        testTag = "onboarding_step2_next"
                    )
                }
            }
        }

        // Step 3: Finger Layout & Playstyle
        AnimatedVisibility(visible = step == 3) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Controls & Playstyle",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimary
                )
                Text(
                    text = "How many fingers do you play with?",
                    fontSize = 13.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp, bottom = 18.dp)
                )

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    FingerLayoutCard(
                        title = "2-Finger (Thumb Player)",
                        subtitle = "Needs higher General sensitivity for swift thumb drag reach",
                        isSelected = selectedFingerLayout == "2-Finger"
                    ) {
                        selectedFingerLayout = "2-Finger"
                    }

                    FingerLayoutCard(
                        title = "3-Finger Claw",
                        subtitle = "Balanced jump/crouch with index; dedicated thumb drag",
                        isSelected = selectedFingerLayout == "3-Finger Claw"
                    ) {
                        selectedFingerLayout = "3-Finger Claw"
                    }

                    FingerLayoutCard(
                        title = "4-Finger Pro Claw",
                        subtitle = "Maximum precision; tighter sensitivity for laser headshots",
                        isSelected = selectedFingerLayout == "4-Finger Claw"
                    ) {
                        selectedFingerLayout = "4-Finger Claw"
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))
                Text(
                    text = "Primary Weapon & Combat Role",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange,
                    modifier = Modifier.align(Alignment.Start)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("All-Rounder", "One-Tap / Rusher", "Sniper").forEach { style ->
                        ChipOption(
                            label = style,
                            isSelected = selectedPlaystyle == style,
                            modifier = Modifier.weight(1f)
                        ) {
                            selectedPlaystyle = style
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    NeonButton(
                        text = "← Back",
                        onClick = { step = 2 },
                        isPrimary = false,
                        modifier = Modifier.weight(1f)
                    )
                    NeonButton(
                        text = "Next: Current Sens →",
                        onClick = { step = 4 },
                        modifier = Modifier.weight(1.5f),
                        testTag = "onboarding_step3_next"
                    )
                }
            }
        }

        // Step 4: Current Sensitivity & Personalized Results
        AnimatedVisibility(visible = step == 4) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Personalized Optimization",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimary
                )
                Text(
                    text = "Enter your current in-game General sensitivity.",
                    fontSize = 13.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
                )

                GamingCard {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Current General Sensitivity",
                                color = TextPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "$currentSensValue",
                                color = NeonOrange,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp
                            )
                        }

                        Slider(
                            value = currentSensValue.toFloat(),
                            onValueChange = { currentSensValue = it.roundToInt() },
                            valueRange = 50f..100f,
                            colors = SliderDefaults.colors(
                                thumbColor = NeonOrange,
                                activeTrackColor = NeonOrange,
                                inactiveTrackColor = DarkSurfaceBorder
                            ),
                            modifier = Modifier.testTag("onboarding_sens_slider")
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        NeonButton(
                            text = "⚡ Calculate Optimal Headshot Sens",
                            onClick = {
                                generatedProfile = viewModel.generateNewSensitivity(
                                    gameVersion = selectedGameVersion,
                                    phoneModel = phoneModel,
                                    fpsSetting = selectedFps,
                                    refreshRateHz = selectedRefreshRate,
                                    fingerLayout = selectedFingerLayout,
                                    playstyle = selectedPlaystyle
                                )
                            },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "calculate_sens_button"
                        )
                    }
                }

                // If calculated, display result card
                val profile = generatedProfile
                if (profile != null) {
                    Spacer(modifier = Modifier.height(16.dp))
                    GamingCard(borderColor = NeonOrange, glowColor = NeonOrange.copy(alpha = 0.3f)) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "AI Recommended Configuration",
                                    fontWeight = FontWeight.Bold,
                                    color = NeonOrange,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = profile.gameVersion,
                                    color = NeonCyan,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                MiniSensResult("General", profile.generalSens, Modifier.weight(1f))
                                MiniSensResult("Red Dot", profile.redDotSens, Modifier.weight(1f))
                                MiniSensResult("2x Scope", profile.scope2xSens, Modifier.weight(1f))
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                MiniSensResult("4x Scope", profile.scope4xSens, Modifier.weight(1f))
                                MiniSensResult("Sniper", profile.sniperSens, Modifier.weight(1f))
                                MiniSensResult("Free Look", profile.freeLookSens, Modifier.weight(1f))
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(DarkSurfaceElevated)
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = "Recommended Fire Button: ${profile.fireButtonSize}% size • Lower-Right Drag Zone • DPI: ${profile.dpiRecommendation}",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    NeonButton(
                        text = "← Back",
                        onClick = { step = 3 },
                        isPrimary = false,
                        modifier = Modifier.weight(1f)
                    )
                    NeonButton(
                        text = "Save & Enter Coach →",
                        onClick = {
                            val prof = generatedProfile ?: viewModel.generateNewSensitivity(
                                gameVersion = selectedGameVersion,
                                phoneModel = phoneModel,
                                fpsSetting = selectedFps,
                                refreshRateHz = selectedRefreshRate,
                                fingerLayout = selectedFingerLayout,
                                playstyle = selectedPlaystyle
                            )
                            viewModel.saveGeneratedProfile(prof, setAsActive = true)
                            viewModel.completeOnboarding()
                        },
                        modifier = Modifier.weight(1.6f),
                        testTag = "onboarding_finish_button"
                    )
                }
            }
        }
    }
}

@Composable
private fun SelectableGameCard(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .border(
                BorderStroke(
                    1.5.dp,
                    if (isSelected) NeonOrange else DarkSurfaceBorder
                ),
                RoundedCornerShape(14.dp)
            ),
        color = if (isSelected) NeonOrange.copy(alpha = 0.12f) else DarkSurface
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.SportsEsports,
                contentDescription = null,
                tint = if (isSelected) NeonOrange else TextSecondary,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = if (isSelected) NeonOrange else TextPrimary,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun FingerLayoutCard(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .border(
                BorderStroke(
                    1.5.dp,
                    if (isSelected) NeonCyan else DarkSurfaceBorder
                ),
                RoundedCornerShape(12.dp)
            ),
        color = if (isSelected) NeonCyan.copy(alpha = 0.1f) else DarkSurface
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.TouchApp,
                contentDescription = null,
                tint = if (isSelected) NeonCyan else TextSecondary,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = if (isSelected) NeonCyan else TextPrimary
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }
        }
    }
}

@Composable
private fun ChipOption(
    label: String,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .border(
                BorderStroke(
                    1.dp,
                    if (isSelected) NeonOrange else DarkSurfaceBorder
                ),
                RoundedCornerShape(10.dp)
            ),
        color = if (isSelected) NeonOrange.copy(alpha = 0.2f) else DarkSurfaceElevated
    ) {
        Box(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) NeonOrange else TextSecondary
            )
        }
    }
}

@Composable
private fun MiniSensResult(
    label: String,
    value: Int,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .border(BorderStroke(1.dp, DarkSurfaceBorder), RoundedCornerShape(8.dp)),
        color = DarkSurfaceElevated
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "$value", fontWeight = FontWeight.ExtraBold, color = NeonOrange, fontSize = 16.sp)
            Text(text = label, fontSize = 10.sp, color = TextSecondary)
        }
    }
}
