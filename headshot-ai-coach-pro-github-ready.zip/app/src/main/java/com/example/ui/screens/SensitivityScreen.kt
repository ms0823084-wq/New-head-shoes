package com.example.ui.screens

import android.os.Build
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SensitivityProfile
import com.example.ui.CoachViewModel
import com.example.ui.components.GamingCard
import com.example.ui.components.NeonButton
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.HeadshotRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonOrange
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
fun SensitivityScreen(
    viewModel: CoachViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val allProfiles by viewModel.allProfiles.collectAsState()
    val defaultProfile by viewModel.defaultProfile.collectAsState()
    val language by viewModel.language.collectAsState()

    // Currently edited sensitivity values
    var general by remember { mutableIntStateOf(defaultProfile?.generalSens ?: 95) }
    var redDot by remember { mutableIntStateOf(defaultProfile?.redDotSens ?: 88) }
    var scope2x by remember { mutableIntStateOf(defaultProfile?.scope2xSens ?: 82) }
    var scope4x by remember { mutableIntStateOf(defaultProfile?.scope4xSens ?: 75) }
    var sniper by remember { mutableIntStateOf(defaultProfile?.sniperSens ?: 50) }
    var freeLook by remember { mutableIntStateOf(defaultProfile?.freeLookSens ?: 72) }

    var gameVersion by remember { mutableStateOf(defaultProfile?.gameVersion ?: "Free Fire MAX") }
    var fingerLayout by remember { mutableStateOf(defaultProfile?.fingerLayout ?: "2-Finger") }
    var playstyle by remember { mutableStateOf(defaultProfile?.playstyle ?: "All-Rounder") }
    var phoneModel by remember {
        mutableStateOf(defaultProfile?.phoneModel ?: "${Build.MANUFACTURER} ${Build.MODEL}")
    }

    var showSaveDialog by remember { mutableStateOf(false) }
    var newProfileName by remember { mutableStateOf("") }
    var showRangeTips by remember { mutableStateOf(true) }

    // Sync when active profile changes
    androidx.compose.runtime.LaunchedEffect(defaultProfile) {
        defaultProfile?.let {
            general = it.generalSens
            redDot = it.redDotSens
            scope2x = it.scope2xSens
            scope4x = it.scope4xSens
            sniper = it.sniperSens
            freeLook = it.freeLookSens
            gameVersion = it.gameVersion
            fingerLayout = it.fingerLayout
            playstyle = it.playstyle
        }
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(horizontal = 16.dp)
            .verticalScroll(scrollState)
    ) {
        Spacer(modifier = Modifier.height(14.dp))

        // Title row with One-Tap Generate button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SENSITIVITY OPTIMIZER",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    color = NeonOrange
                )
                Text(
                    text = if (language == "hi") "फ्री फायर परफेक्ट हेडशॉट सेटिंग्स" else "Calibrated to touch sampling & drag physics",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }

            NeonButton(
                text = "⚡ 1-Tap AI Gen",
                onClick = {
                    val gen = viewModel.generateNewSensitivity(
                        gameVersion = gameVersion,
                        phoneModel = phoneModel,
                        fpsSetting = "High 60 FPS",
                        refreshRateHz = 90,
                        fingerLayout = fingerLayout,
                        playstyle = playstyle
                    )
                    general = gen.generalSens
                    redDot = gen.redDotSens
                    scope2x = gen.scope2xSens
                    scope4x = gen.scope4xSens
                    sniper = gen.sniperSens
                    freeLook = gen.freeLookSens
                    Toast.makeText(context, "Generated optimal settings for $phoneModel!", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.height(38.dp),
                testTag = "one_tap_gen_button"
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Game Version & Finger Layout Selectors
        GamingCard {
            Column {
                Text(
                    text = "Target Configuration",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Free Fire MAX", "Free Fire").forEach { ver ->
                        val isSel = gameVersion == ver
                        OptionPill(
                            label = ver,
                            isSelected = isSel,
                            modifier = Modifier.weight(1f)
                        ) {
                            gameVersion = ver
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("2-Finger", "3-Finger Claw", "4-Finger Claw").forEach { fingers ->
                        val isSel = fingerLayout == fingers
                        OptionPill(
                            label = fingers,
                            isSelected = isSel,
                            modifier = Modifier.weight(1f)
                        ) {
                            fingerLayout = fingers
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Sensitivity Sliders Panel (General, Red Dot, 2x, 4x, Sniper, Free Look)
        GamingCard {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "IN-GAME SENSITIVITY SLIDERS (0-100)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonCyan
                    )

                    IconButton(
                        onClick = {
                            val copyText = "Free Fire Sensitivity:\nGeneral: $general\nRed Dot: $redDot\n2x Scope: $scope2x\n4x Scope: $scope4x\nSniper: $sniper\nFree Look: $freeLook\nFire Button: 48%\nGenerated by Headshot AI Coach Pro"
                            clipboardManager.setText(AnnotatedString(copyText))
                            Toast.makeText(context, "Copied sensitivity settings!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy Settings",
                            tint = NeonCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                SensitivitySliderRow("General (कैमरा / ड्रैग)", general, NeonOrange) { general = it }
                SensitivitySliderRow("Red Dot (रेड डॉट)", redDot, HeadshotRed) { redDot = it }
                SensitivitySliderRow("2x Scope (2x स्कोप)", scope2x, NeonGold) { scope2x = it }
                SensitivitySliderRow("4x Scope (4x स्कोप)", scope4x, NeonGreen) { scope4x = it }
                SensitivitySliderRow("Sniper Scope (स्नाइपर)", sniper, NeonCyan) { sniper = it }
                SensitivitySliderRow("Free Look (फ्री लुक)", freeLook, TextSecondary) { freeLook = it }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    NeonButton(
                        text = "💾 Save as Profile",
                        onClick = {
                            newProfileName = "$gameVersion Custom ($fingerLayout)"
                            showSaveDialog = true
                        },
                        isPrimary = false,
                        modifier = Modifier.weight(1f),
                        testTag = "save_profile_button"
                    )

                    NeonButton(
                        text = "✔ Set as Active",
                        onClick = {
                            val prof = SensitivityProfile(
                                profileName = "$gameVersion Active ($fingerLayout)",
                                gameVersion = gameVersion,
                                phoneModel = phoneModel,
                                fpsSetting = "High 60 FPS",
                                refreshRateHz = 90,
                                fingerLayout = fingerLayout,
                                generalSens = general,
                                redDotSens = redDot,
                                scope2xSens = scope2x,
                                scope4xSens = scope4x,
                                sniperSens = sniper,
                                freeLookSens = freeLook,
                                fireButtonSize = if (fingerLayout == "2-Finger") 46 else 50,
                                fireButtonPosition = "Lower Right Corner",
                                dpiRecommendation = 411,
                                playstyle = playstyle,
                                isDefault = true
                            )
                            viewModel.saveGeneratedProfile(prof, setAsActive = true)
                            Toast.makeText(context, "Saved as Active Profile!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f),
                        testTag = "set_active_profile_button"
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Distance Combat Guidance (Close, Mid, Long)
        GamingCard(
            onClick = { showRangeTips = !showRangeTips }
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🎯 COMBAT RANGE DRAG GUIDANCE",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonGold
                    )
                    Icon(
                        imageVector = if (showRangeTips) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = NeonGold
                    )
                }

                AnimatedVisibility(visible = showRangeTips) {
                    Column(modifier = Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        RangeGuideItem(
                            title = "Close-Range Fights (0 - 10m)",
                            dragMethod = "Rotation Drag / J-Drag",
                            speed = "Explosive Swipe (Fast)",
                            description = if (language == "hi")
                                "दुश्मन के सिर की दिशा में फायर बटन को 'J' आकार में तेजी से घुमाएं। फायर बटन साइज 46% रखें ताकि ऊपर ड्रैग करने के लिए ज्यादा जगह मिले।"
                            else
                                "Enemies move fast across your screen. Curve your fire button upward in a J-shape toward their running direction."
                        )

                        RangeGuideItem(
                            title = "Mid-Range Fights (10 - 30m)",
                            dragMethod = "Straight Vertical Drag",
                            speed = "Controlled Medium Flick",
                            description = if (language == "hi")
                                "क्रॉसहेयर को पहले छाती के पास रखें (व्हाइट-टू-रेड), फिर फायर बटन को सीधा ऊपर सिर तक ड्रैग करें।"
                            else
                                "Hold crosshair just off the chest until it turns red, then pull fire button straight up smoothly to lock head level."
                        )

                        RangeGuideItem(
                            title = "Long-Range Fights (30m+)",
                            dragMethod = "Micro-Tap Upward Drag",
                            speed = "Gentle Micro-Drag",
                            description = if (language == "hi")
                                "लंबी दूरी पर तेज ड्रैग करने से गोली सिर के ऊपर निकल जाएगी। केवल हल्का सा ऊपर स्पर्श करें।"
                            else
                                "Do NOT flick hard or your crosshair will fly over the target head. Use minimal upward micro-adjustment with single taps."
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Saved Profiles Manager
        GamingCard {
            Column {
                Text(
                    text = "SAVED PROFILES (${allProfiles.size})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
                Spacer(modifier = Modifier.height(10.dp))

                if (allProfiles.isEmpty()) {
                    Text(
                        text = "No saved profiles yet. Tap 'Save as Profile' above.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                } else {
                    allProfiles.forEach { profile ->
                        SavedProfileItem(
                            profile = profile,
                            isActive = profile.isDefault,
                            onSelect = { viewModel.setActiveProfile(profile) },
                            onDelete = { viewModel.deleteProfile(profile) }
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }

    // Save Profile Dialog
    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            containerColor = DarkSurface,
            shape = RoundedCornerShape(16.dp),
            title = {
                Text(text = "Save Sensitivity Profile", color = TextPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text(text = "Enter a name for this configuration:", color = TextSecondary, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newProfileName,
                        onValueChange = { newProfileName = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = NeonOrange,
                            unfocusedBorderColor = DarkSurfaceBorder
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val prof = SensitivityProfile(
                            profileName = newProfileName.ifBlank { "Custom Profile" },
                            gameVersion = gameVersion,
                            phoneModel = phoneModel,
                            fpsSetting = "High 60 FPS",
                            refreshRateHz = 90,
                            fingerLayout = fingerLayout,
                            generalSens = general,
                            redDotSens = redDot,
                            scope2xSens = scope2x,
                            scope4xSens = scope4x,
                            sniperSens = sniper,
                            freeLookSens = freeLook,
                            fireButtonSize = 48,
                            fireButtonPosition = "Lower Right Corner",
                            dpiRecommendation = 411,
                            playstyle = playstyle,
                            isDefault = true
                        )
                        viewModel.saveGeneratedProfile(prof, setAsActive = true)
                        showSaveDialog = false
                        Toast.makeText(context, "Saved & Activated: ${prof.profileName}", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonOrange)
                ) {
                    Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Button(
                    onClick = { showSaveDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated)
                ) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun SensitivitySliderRow(
    title: String,
    value: Int,
    accentColor: Color,
    onValueChange: (Int) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Minus button
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceElevated)
                        .clickable { if (value > 0) onValueChange(value - 1) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "-", color = TextSecondary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "$value",
                    color = accentColor,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.width(32.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                // Plus button
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceElevated)
                        .clickable { if (value < 100) onValueChange(value + 1) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "+", color = TextSecondary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }

        Slider(
            value = value.toFloat(),
            onValueChange = { onValueChange(it.roundToInt()) },
            valueRange = 0f..100f,
            colors = SliderDefaults.colors(
                thumbColor = accentColor,
                activeTrackColor = accentColor,
                inactiveTrackColor = DarkSurfaceBorder
            ),
            modifier = Modifier.height(28.dp)
        )
    }
}

@Composable
private fun OptionPill(
    label: String,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .border(
                BorderStroke(1.dp, if (isSelected) NeonOrange else DarkSurfaceBorder),
                RoundedCornerShape(8.dp)
            ),
        color = if (isSelected) NeonOrange.copy(alpha = 0.18f) else DarkSurfaceElevated
    ) {
        Box(
            modifier = Modifier.padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) NeonOrange else TextSecondary
            )
        }
    }
}

@Composable
private fun RangeGuideItem(
    title: String,
    dragMethod: String,
    speed: String,
    description: String
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp)),
        color = DarkSurfaceElevated
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = title, fontWeight = FontWeight.Bold, color = NeonOrange, fontSize = 13.sp)
                Text(text = speed, fontWeight = FontWeight.SemiBold, color = NeonCyan, fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = "Technique: $dragMethod", fontWeight = FontWeight.Medium, color = NeonGold, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = description, color = TextSecondary, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SavedProfileItem(
    profile: SensitivityProfile,
    isActive: Boolean,
    onSelect: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable { onSelect() }
            .border(
                BorderStroke(1.dp, if (isActive) NeonGreen else DarkSurfaceBorder),
                RoundedCornerShape(10.dp)
            ),
        color = if (isActive) NeonGreen.copy(alpha = 0.08f) else DarkSurfaceElevated
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = profile.profileName,
                        fontWeight = FontWeight.Bold,
                        color = if (isActive) NeonGreen else TextPrimary,
                        fontSize = 13.sp
                    )
                    if (isActive) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(NeonGreen)
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(text = "ACTIVE", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
                Text(
                    text = "Gen: ${profile.generalSens} • Red Dot: ${profile.redDotSens} • 2x: ${profile.scope2xSens} • 4x: ${profile.scope4xSens}",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }

            IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete Profile",
                    tint = TextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
