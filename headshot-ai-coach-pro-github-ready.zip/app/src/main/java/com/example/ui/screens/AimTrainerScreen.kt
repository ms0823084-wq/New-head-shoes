package com.example.ui.screens

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppScreen
import com.example.ui.CoachViewModel
import com.example.ui.components.GamingCard
import com.example.ui.components.NeonButton
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.HeadshotRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonOrange
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

@Composable
fun AimTrainerScreen(
    viewModel: CoachViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val aimState by viewModel.aimState.collectAsState()
    val language by viewModel.language.collectAsState()

    var showGuideOverlay by remember { mutableStateOf(true) }
    var showSummaryDialog by remember { mutableStateOf(false) }

    // Target position states relative to arena width/height (0.0 to 1.0)
    var targetNormX by remember { mutableFloatStateOf(0.5f) }
    var targetSpeed by remember { mutableFloatStateOf(0.008f) }
    var targetMovingRight by remember { mutableStateOf(true) }

    // Target spawn time for reaction calculation
    var targetSpawnTimeMs by remember { mutableLongStateOf(System.currentTimeMillis()) }

    // Drag gesture tracking
    var dragStartOffset by remember { mutableStateOf<Offset?>(null) }
    var currentDragOffset by remember { mutableStateOf<Offset?>(null) }
    var touchStartTime by remember { mutableLongStateOf(0L) }
    var isDraggingFireButton by remember { mutableStateOf(false) }

    // Floating damage effect
    var activeDamageText by remember { mutableStateOf<String?>(null) }
    var activeDamageColor by remember { mutableStateOf(HeadshotRed) }

    // Haptic vibrator
    val vibrator = remember(context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    fun triggerHaptic(isHeadshot: Boolean) {
        try {
            if (isHeadshot) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(70, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(70)
                }
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(25, 80))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(25)
                }
            }
        } catch (_: Exception) {}
    }

    // Round countdown loop
    LaunchedEffect(aimState.isPlaying) {
        if (aimState.isPlaying) {
            var remaining = aimState.roundDurationSeconds
            while (remaining > 0 && aimState.isPlaying) {
                delay(1000L)
                remaining--
                if (!aimState.isPlaying) break
                if (remaining == 0) {
                    viewModel.finishRound()
                    showSummaryDialog = true
                }
            }
        }
    }

    // Target animation loop
    LaunchedEffect(aimState.isPlaying, aimState.difficulty) {
        if (aimState.isPlaying) {
            val speedFactor = when (aimState.difficulty) {
                "BEGINNER" -> 0.003f
                "INTERMEDIATE" -> 0.007f
                "ADVANCED" -> 0.013f
                else -> 0.007f
            }

            while (aimState.isPlaying) {
                delay(16L) // ~60 FPS
                if (aimState.difficulty != "BEGINNER") {
                    if (targetMovingRight) {
                        targetNormX += speedFactor
                        if (targetNormX >= 0.82f) targetMovingRight = false
                    } else {
                        targetNormX -= speedFactor
                        if (targetNormX <= 0.18f) targetMovingRight = true
                    }
                }
            }
        }
    }

    // Clear damage text after 900ms
    LaunchedEffect(activeDamageText) {
        if (activeDamageText != null) {
            delay(900L)
            activeDamageText = null
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        // Top Toolbar: Mode, Difficulty, Distance, Guide Toggle
        TopTrainingControls(
            aimState = aimState,
            language = language,
            showGuide = showGuideOverlay,
            onToggleGuide = { showGuideOverlay = !showGuideOverlay },
            onModeChanged = { mode -> viewModel.startTrainer(gameMode = mode) },
            onDifficultyChanged = { diff -> viewModel.startTrainer(difficulty = diff) },
            onDistanceChanged = { dist -> viewModel.startTrainer(distance = dist) }
        )

        // Training Arena
        BoxWithConstraints(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(16.dp))
                .border(BorderStroke(1.dp, DarkSurfaceBorder), RoundedCornerShape(16.dp))
                .background(DarkSurface)
        ) {
            val arenaWidth = constraints.maxWidth.toFloat()
            val arenaHeight = constraints.maxHeight.toFloat()

            // Target dimensions based on distance
            val targetScale = when (aimState.distance) {
                "CLOSE" -> 1.35f
                "MID" -> 1.0f
                "LONG" -> 0.65f
                else -> 1.0f
            }

            val headRadius = 26f * targetScale
            val bodyWidth = 56f * targetScale
            val bodyHeight = 90f * targetScale

            val targetCenterX = targetNormX * arenaWidth
            val targetCenterY = arenaHeight * 0.32f

            val headCenter = Offset(targetCenterX, targetCenterY - (bodyHeight * 0.5f) - headRadius + 6f)
            val bodyRect = Offset(targetCenterX - (bodyWidth / 2f), targetCenterY - (bodyHeight / 2f))

            // Canvas drawing shooting range & target
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Range grid lines
                val gridColor = Color(0x1A00E5FF)
                for (y in 0..size.height.toInt() step 90) {
                    drawLine(gridColor, Offset(0f, y.toFloat()), Offset(size.width, y.toFloat()), 1f)
                }
                for (x in 0..size.width.toInt() step 90) {
                    drawLine(gridColor, Offset(x.toFloat(), 0f), Offset(x.toFloat(), size.height), 1f)
                }

                // Range distance markers
                drawLine(
                    color = Color(0x33FF5E1A),
                    start = Offset(0f, targetCenterY + (bodyHeight * 0.6f)),
                    end = Offset(size.width, targetCenterY + (bodyHeight * 0.6f)),
                    strokeWidth = 2f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f)
                )

                // Draw Target Dummy
                // 1. Body / Torso
                drawRoundRect(
                    color = Color(0xFF2C394F),
                    topLeft = bodyRect,
                    size = Size(bodyWidth, bodyHeight),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
                )
                // Body chest outline / center target
                drawRoundRect(
                    color = NeonCyan.copy(alpha = 0.5f),
                    topLeft = Offset(bodyRect.x + 8f, bodyRect.y + 12f),
                    size = Size(bodyWidth - 16f, bodyHeight - 24f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f),
                    style = Stroke(width = 1.5f)
                )

                // 2. Head (Headshot Zone)
                drawCircle(
                    color = Color(0xFF1E2838),
                    radius = headRadius,
                    center = headCenter
                )
                // Head neon red ring
                drawCircle(
                    color = HeadshotRed,
                    radius = headRadius,
                    center = headCenter,
                    style = Stroke(width = 3.5f)
                )
                // Headshot bullseye dot
                drawCircle(
                    color = NeonOrange,
                    radius = headRadius * 0.35f,
                    center = headCenter
                )

                // If Guide Overlay is enabled, draw recommended Drag Curve trajectory!
                if (showGuideOverlay) {
                    val guideStart = Offset(targetCenterX, targetCenterY + 20f)
                    val guideEnd = headCenter

                    val guidePath = Path().apply {
                        moveTo(guideStart.x, guideStart.y)
                        // Slight J-curve upward if close range, straight vertical if mid/long
                        if (aimState.distance == "CLOSE") {
                            cubicTo(
                                guideStart.x + 18f, guideStart.y - 15f,
                                guideEnd.x + 10f, guideEnd.y + 20f,
                                guideEnd.x, guideEnd.y
                            )
                        } else {
                            lineTo(guideEnd.x, guideEnd.y)
                        }
                    }

                    drawPath(
                        path = guidePath,
                        color = NeonGreen.copy(alpha = 0.7f),
                        style = Stroke(
                            width = 3f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                        )
                    )
                }

                // If user is dragging fire button, draw live drag laser indicator on target
                val dragStart = dragStartOffset
                val dragCurr = currentDragOffset
                if (isDraggingFireButton && dragStart != null && dragCurr != null) {
                    val dragDeltaY = dragStart.y - dragCurr.y
                    val dragDeltaX = dragCurr.x - dragStart.x

                    // Simulated crosshair lift
                    val sensMultiplier = 2.4f
                    val crosshairX = targetCenterX + (dragDeltaX * sensMultiplier * 0.4f)
                    val crosshairY = (targetCenterY + 15f) - (dragDeltaY * sensMultiplier)

                    // Draw Crosshair
                    drawCircle(
                        color = NeonCyan,
                        radius = 18f,
                        center = Offset(crosshairX, crosshairY),
                        style = Stroke(width = 2f)
                    )
                    drawCircle(
                        color = if (hypot(crosshairX - headCenter.x, crosshairY - headCenter.y) <= headRadius) HeadshotRed else NeonCyan,
                        radius = 4f,
                        center = Offset(crosshairX, crosshairY)
                    )
                }
            }

            // Damage Number Popups
            val damageMsg = activeDamageText
            if (damageMsg != null) {
                Box(
                    modifier = Modifier
                        .offset {
                            IntOffset(
                                (targetCenterX - 80).roundToInt(),
                                (headCenter.y - 85).roundToInt()
                            )
                        }
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black.copy(alpha = 0.75f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = damageMsg,
                        color = activeDamageColor,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }

            // Drag Guide Tip Pill
            if (showGuideOverlay) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 10.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(DarkBg.copy(alpha = 0.85f))
                        .border(BorderStroke(1.dp, NeonGreen.copy(alpha = 0.4f)), RoundedCornerShape(20.dp))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = if (language == "hi")
                            "गाइड: चेस्ट से शुरू करें और फायर बटन को तेजी से ऊपर हेड की तरफ ड्रैग करें"
                        else
                            "Drag Guide: Start chest-level, flick Fire Button swiftly upward to the red head circle",
                        color = NeonGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Real-time Drag Velocity & Hit Feedback bar at bottom of arena
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(12.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(DarkSurfaceElevated.copy(alpha = 0.9f))
                    .border(BorderStroke(1.dp, DarkSurfaceBorder), RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Column {
                    Text(
                        text = aimState.feedbackMessage,
                        color = when (aimState.lastHitType) {
                            "HEADSHOT" -> HeadshotRed
                            "BODY" -> NeonGold
                            "OVERSHOOT" -> NeonOrange
                            else -> TextSecondary
                        },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Drag Speed: ${aimState.dragSpeedRating} • Reaction: ${aimState.currentReactionTimeMs}ms",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            }
        }

        // Bottom Controls: Live Stats HUD + Interactive Free Fire Drag Button
        BottomSimulatorControls(
            aimState = aimState,
            isDragging = isDraggingFireButton,
            onFireDragStart = { startPos ->
                isDraggingFireButton = true
                dragStartOffset = startPos
                currentDragOffset = startPos
                touchStartTime = System.currentTimeMillis()
            },
            onFireDrag = { currentPos ->
                currentDragOffset = currentPos
            },
            onFireDragEnd = {
                val start = dragStartOffset
                val curr = currentDragOffset
                val durationMs = (System.currentTimeMillis() - touchStartTime).coerceAtLeast(1L)

                if (start != null && curr != null) {
                    val deltaY = start.y - curr.y // Upward drag distance
                    val deltaX = curr.x - start.x
                    val dragVelocity = (deltaY / (durationMs.toFloat() / 1000f)).coerceAtLeast(0f)
                    val reaction = (System.currentTimeMillis() - targetSpawnTimeMs).coerceIn(120L, 850L)

                    // Target calculation
                    // Ideal drag distance to reach head: ~90 to 230 pixels depending on distance
                    val minDragRequired = when (aimState.distance) {
                        "CLOSE" -> 110f
                        "MID" -> 85f
                        "LONG" -> 60f
                        else -> 85f
                    }
                    val maxDragAllowed = when (aimState.distance) {
                        "CLOSE" -> 260f
                        "MID" -> 210f
                        "LONG" -> 160f
                        else -> 210f
                    }

                    val isHeadshot = deltaY in minDragRequired..maxDragAllowed && abs(deltaX) < 110f
                    val isOvershoot = deltaY > maxDragAllowed
                    val isUndershoot = deltaY in 15f..minDragRequired
                    val isBody = isUndershoot || (deltaY < 15f && abs(deltaX) < 80f)

                    if (isHeadshot) {
                        activeDamageText = "⚡ 495 HEADSHOT!"
                        activeDamageColor = HeadshotRed
                        triggerHaptic(true)
                    } else if (isOvershoot) {
                        activeDamageText = "Overshot (Dragged Too High)"
                        activeDamageColor = NeonOrange
                        triggerHaptic(false)
                    } else if (isBody) {
                        activeDamageText = "45 Body Hit"
                        activeDamageColor = NeonGold
                        triggerHaptic(false)
                    } else {
                        activeDamageText = "MISS"
                        activeDamageColor = TextMuted
                    }

                    viewModel.registerShot(
                        isHeadshot = isHeadshot,
                        isBodyShot = isBody,
                        isOvershoot = isOvershoot,
                        isUndershoot = isUndershoot,
                        reactionTimeMs = reaction,
                        dragVelocity = dragVelocity
                    )

                    // Reset reaction timer for next target
                    targetSpawnTimeMs = System.currentTimeMillis()
                }

                isDraggingFireButton = false
                dragStartOffset = null
                currentDragOffset = null
            },
            onStartTrainer = { viewModel.startTrainer() },
            onStopTrainer = {
                viewModel.finishRound()
                showSummaryDialog = true
            }
        )
    }

    // Round Summary & AI Coach Recommendation Dialog
    if (showSummaryDialog) {
        val total = aimState.totalShots.coerceAtLeast(1)
        val hsPct = ((aimState.headshots.toFloat() / total) * 100f).roundToInt()
        val avgReact = if (aimState.reactionTimes.isNotEmpty()) aimState.reactionTimes.average().roundToInt() else 310

        AlertDialog(
            onDismissRequest = { showSummaryDialog = false },
            containerColor = DarkSurface,
            shape = RoundedCornerShape(18.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.SportsEsports,
                        contentDescription = null,
                        tint = NeonOrange,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (language == "hi") "ट्रेनिंग राउंड रिपोर्ट" else "Training Round Summary",
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimary,
                        fontSize = 18.sp
                    )
                }
            },
            text = {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        DialogStatPill("Headshots", "${aimState.headshots}/$total ($hsPct%)", HeadshotRed, Modifier.weight(1f))
                        DialogStatPill("Avg Reaction", "${avgReact}ms", NeonCyan, Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        DialogStatPill("Overshoots", "${aimState.overshoots}", NeonOrange, Modifier.weight(1f))
                        DialogStatPill("Undershoots", "${aimState.undershoots}", NeonGold, Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // AI Coach Analysis for this round
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .border(BorderStroke(1.dp, NeonGreen.copy(alpha = 0.4f)), RoundedCornerShape(10.dp)),
                        color = NeonGreen.copy(alpha = 0.08f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "🧠 AI Coach Recommendation:",
                                fontWeight = FontWeight.Bold,
                                color = NeonGreen,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = when {
                                    aimState.overshoots > total * 0.35f ->
                                        "You are overshooting target heads! Lower your General sensitivity by 3 points or apply a shorter drag flick."
                                    aimState.undershoots > total * 0.35f ->
                                        "Stuck on body hits! Increase upward drag stroke speed or bump General sensitivity by 4 points."
                                    hsPct >= 60 ->
                                        "Phenomenal drag accuracy! Step up to Advanced moving targets to master moving enemies."
                                    else ->
                                        "Keep crosshair at neck level before starting drag. Practise steady daily routines."
                                },
                                color = TextPrimary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSummaryDialog = false
                        viewModel.startTrainer()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonOrange),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Train Again", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Button(
                    onClick = {
                        showSummaryDialog = false
                        viewModel.setScreen(AppScreen.ANALYTICS)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("View Analytics", color = NeonCyan)
                }
            }
        )
    }
}

@Composable
private fun TopTrainingControls(
    aimState: com.example.ui.AimTrainerState,
    language: String,
    showGuide: Boolean,
    onToggleGuide: () -> Unit,
    onModeChanged: (String) -> Unit,
    onDifficultyChanged: (String) -> Unit,
    onDistanceChanged: (String) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = DarkSurfaceElevated
    ) {
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
            // Mode row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "AIM TRAINER SIMULATOR",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = NeonOrange
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Guide toggle button
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .border(
                                BorderStroke(
                                    1.dp,
                                    if (showGuide) NeonGreen else DarkSurfaceBorder
                                ),
                                RoundedCornerShape(8.dp)
                            ),
                        color = if (showGuide) NeonGreen.copy(alpha = 0.15f) else DarkSurface
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Drag Guide",
                                color = if (showGuide) NeonGreen else TextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.pointerInput(Unit) {
                                    onToggleGuide()
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Selector Chips: Difficulty & Distance
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("BEGINNER", "INTERMEDIATE", "ADVANCED").forEach { diff ->
                    val isSel = aimState.difficulty == diff
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .border(
                                BorderStroke(1.dp, if (isSel) NeonCyan else DarkSurfaceBorder),
                                RoundedCornerShape(6.dp)
                            ),
                        color = if (isSel) NeonCyan.copy(alpha = 0.18f) else DarkSurface
                    ) {
                        Box(
                            modifier = Modifier
                                .padding(vertical = 4.dp)
                                .pointerInput(diff) { onDifficultyChanged(diff) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = diff.take(3),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSel) NeonCyan else TextSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(4.dp))

                listOf("CLOSE", "MID", "LONG").forEach { dist ->
                    val isSel = aimState.distance == dist
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .border(
                                BorderStroke(1.dp, if (isSel) NeonOrange else DarkSurfaceBorder),
                                RoundedCornerShape(6.dp)
                            ),
                        color = if (isSel) NeonOrange.copy(alpha = 0.18f) else DarkSurface
                    ) {
                        Box(
                            modifier = Modifier
                                .padding(vertical = 4.dp)
                                .pointerInput(dist) { onDistanceChanged(dist) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = dist,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSel) NeonOrange else TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomSimulatorControls(
    aimState: com.example.ui.AimTrainerState,
    isDragging: Boolean,
    onFireDragStart: (Offset) -> Unit,
    onFireDrag: (Offset) -> Unit,
    onFireDragEnd: () -> Unit,
    onStartTrainer: () -> Unit,
    onStopTrainer: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = DarkSurface
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 14.dp, vertical = 10.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Live Stats Counter
            Column(modifier = Modifier.weight(1f)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column {
                        Text(
                            text = "${aimState.headshots}",
                            color = HeadshotRed,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(text = "Headshots", color = TextMuted, fontSize = 10.sp)
                    }

                    Column {
                        val pct = if (aimState.totalShots > 0)
                            ((aimState.headshots.toFloat() / aimState.totalShots) * 100f).roundToInt()
                        else 0
                        Text(
                            text = "$pct%",
                            color = NeonOrange,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(text = "Accuracy", color = TextMuted, fontSize = 10.sp)
                    }

                    Column {
                        Text(
                            text = "${aimState.totalShots}",
                            color = TextPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(text = "Shots", color = TextMuted, fontSize = 10.sp)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                if (!aimState.isPlaying) {
                    NeonButton(
                        text = "▶ Start 30s Drill",
                        onClick = onStartTrainer,
                        modifier = Modifier.height(38.dp),
                        testTag = "start_aim_drill_btn"
                    )
                } else {
                    NeonButton(
                        text = "⏹ Stop Round",
                        onClick = onStopTrainer,
                        isPrimary = false,
                        modifier = Modifier.height(38.dp),
                        testTag = "stop_aim_drill_btn"
                    )
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Realistic Free Fire Drag Fire Button
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "SWIPE UP TO DRAG",
                    color = NeonOrange,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))

                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    if (isDragging) NeonOrange else Color(0xFF2C1E18),
                                    Color(0xFF160E0B)
                                )
                            )
                        )
                        .border(
                            BorderStroke(
                                if (isDragging) 3.dp else 2.dp,
                                if (isDragging) NeonCyan else NeonOrange
                            ),
                            CircleShape
                        )
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { offset -> onFireDragStart(offset) },
                                onDrag = { change, dragAmount ->
                                    change.consume()
                                    onFireDrag(change.position)
                                },
                                onDragEnd = { onFireDragEnd() },
                                onDragCancel = { onFireDragEnd() }
                            )
                        }
                        .testTag("fire_drag_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowUpward,
                            contentDescription = "Drag Upward",
                            tint = if (isDragging) Color.Black else NeonOrange,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "FIRE",
                            color = if (isDragging) Color.Black else TextPrimary,
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DialogStatPill(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.3f)), RoundedCornerShape(8.dp)),
        color = DarkSurfaceElevated
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = value, color = color, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(text = label, color = TextSecondary, fontSize = 10.sp)
        }
    }
}
