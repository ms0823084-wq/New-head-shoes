package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Esports Gaming Dark Theme Palette
val DarkBg = Color(0xFF0A0D14)
val DarkSurface = Color(0xFF131822)
val DarkSurfaceElevated = Color(0xFF1B2332)
val DarkSurfaceBorder = Color(0xFF263248)

val NeonOrange = Color(0xFFFF5E1A)
val NeonOrangeLight = Color(0xFFFF7E3D)
val NeonOrangeDark = Color(0xFFC74309)

val NeonCyan = Color(0xFF00E5FF)
val NeonCyanLight = Color(0xFF80F2FF)
val NeonCyanDark = Color(0xFF009EB0)

val NeonGold = Color(0xFFFFD500)
val NeonGreen = Color(0xFF00E676)
val HeadshotRed = Color(0xFFFF2A4B)

val TextPrimary = Color(0xFFF0F4FC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val CardGlow = Color(0x33FF5E1A)
val CyanGlow = Color(0x3300E5FF)
