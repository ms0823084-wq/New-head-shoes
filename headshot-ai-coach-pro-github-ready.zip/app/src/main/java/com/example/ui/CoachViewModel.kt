package com.example.ui

import android.app.Application
import android.content.Context
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.HeadshotCoachEngine
import com.example.data.AiCoachInsight
import com.example.data.AppDatabase
import com.example.data.CoachRepository
import com.example.data.SensitivityProfile
import com.example.data.TrainingSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppScreen {
    HOME,
    SENSITIVITY,
    AIM_TRAINER,
    ANALYTICS,
    TRAINING_PLANS,
    SETTINGS
}

data class AimTrainerState(
    val isPlaying: Boolean = false,
    val isRoundComplete: Boolean = false,
    val gameMode: String = "DRAG_AIM", // "DRAG_AIM", "ONE_TAP", "REACTION_TIME", "CROSSHAIR_PLACEMENT"
    val difficulty: String = "INTERMEDIATE", // "BEGINNER", "INTERMEDIATE", "ADVANCED"
    val distance: String = "MID", // "CLOSE", "MID", "LONG"
    val roundDurationSeconds: Int = 30,
    val timeRemainingSeconds: Int = 30,
    val totalShots: Int = 0,
    val headshots: Int = 0,
    val bodyShots: Int = 0,
    val misses: Int = 0,
    val overshoots: Int = 0,
    val undershoots: Int = 0,
    val currentReactionTimeMs: Long = 0,
    val reactionTimes: List<Long> = emptyList(),
    val lastHitType: String? = null, // "HEADSHOT", "BODY", "MISS", "OVERSHOOT", "UNDERSHOOT"
    val lastDamageValue: Int? = null,
    val dragSpeedRating: String = "OPTIMAL", // "TOO_SLOW", "OPTIMAL", "TOO_FAST"
    val feedbackMessage: String = "Touch & Drag the Fire Button upward toward the head!"
)

class CoachViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("headshot_coach_prefs", Context.MODE_PRIVATE)
    private val repository: CoachRepository

    init {
        val db = AppDatabase.getInstance(application)
        repository = CoachRepository(db.sensitivityProfileDao(), db.trainingSessionDao())
        viewModelScope.launch {
            repository.initializeDefaultsIfNeeded()
        }
    }

    // App Navigation
    private val _currentScreen = MutableStateFlow(AppScreen.HOME)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Language setting ("en" or "hi")
    private val _language = MutableStateFlow(prefs.getString("pref_lang", "en") ?: "en")
    val language: StateFlow<String> = _language.asStateFlow()

    // Onboarding status
    private val _hasCompletedOnboarding = MutableStateFlow(
        prefs.getBoolean("pref_onboarding_completed", false)
    )
    val hasCompletedOnboarding: StateFlow<Boolean> = _hasCompletedOnboarding.asStateFlow()

    // Data streams
    val allProfiles: StateFlow<List<SensitivityProfile>> = repository.allProfiles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val defaultProfile: StateFlow<SensitivityProfile?> = repository.defaultProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allSessions: StateFlow<List<TrainingSession>> = repository.allSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val headshotImprovementScore: StateFlow<Int> = allSessions.combine(MutableStateFlow(Unit)) { sessions, _ ->
        HeadshotCoachEngine.calculateScore(sessions)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _aiInsight = MutableStateFlow(
        AiCoachInsight(
            title = "AI Coach Analyzing",
            subtitle = "Calibrating baseline",
            recommendation = "Complete your first training session in the Aim Trainer.",
            sensitivityAdjustmentTip = "Recommended starting General: 95.",
            suggestedDrill = "Drag Aim Headshot Drill",
            severity = "INFO"
        )
    )
    val aiInsight: StateFlow<AiCoachInsight> = _aiInsight.asStateFlow()

    private val _beforeAfter = MutableStateFlow<Pair<Int, Int>?>(null)
    val beforeAfter: StateFlow<Pair<Int, Int>?> = _beforeAfter.asStateFlow()

    // Aim Trainer Game State
    private val _aimState = MutableStateFlow(AimTrainerState())
    val aimState: StateFlow<AimTrainerState> = _aimState.asStateFlow()

    // Temporary profile being edited / generated
    private val _activeEditingProfile = MutableStateFlow<SensitivityProfile?>(null)
    val activeEditingProfile: StateFlow<SensitivityProfile?> = _activeEditingProfile.asStateFlow()

    init {
        refreshDiagnostics()
    }

    fun setScreen(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun setLanguage(lang: String) {
        _language.value = lang
        prefs.edit().putString("pref_lang", lang).apply()
    }

    fun completeOnboarding() {
        _hasCompletedOnboarding.value = true
        prefs.edit().putBoolean("pref_onboarding_completed", true).apply()
    }

    fun restartOnboarding() {
        _hasCompletedOnboarding.value = false
        prefs.edit().putBoolean("pref_onboarding_completed", false).apply()
    }

    fun refreshDiagnostics() {
        viewModelScope.launch {
            _aiInsight.value = repository.getAiCoachInsight()
            _beforeAfter.value = repository.getBeforeAfterComparison()
        }
    }

    fun generateNewSensitivity(
        gameVersion: String,
        phoneModel: String,
        fpsSetting: String,
        refreshRateHz: Int,
        fingerLayout: String,
        playstyle: String
    ): SensitivityProfile {
        val generated = HeadshotCoachEngine.generateSensitivity(
            gameVersion = gameVersion,
            phoneModel = phoneModel,
            fpsSetting = fpsSetting,
            refreshRateHz = refreshRateHz,
            fingerLayout = fingerLayout,
            playstyle = playstyle
        )
        _activeEditingProfile.value = generated
        return generated
    }

    fun saveGeneratedProfile(profile: SensitivityProfile, setAsActive: Boolean = true) {
        viewModelScope.launch {
            val toSave = profile.copy(isDefault = setAsActive)
            repository.saveProfile(toSave)
            refreshDiagnostics()
        }
    }

    fun setActiveProfile(profile: SensitivityProfile) {
        viewModelScope.launch {
            repository.setDefaultProfile(profile.id)
            _activeEditingProfile.value = profile
            refreshDiagnostics()
        }
    }

    fun deleteProfile(profile: SensitivityProfile) {
        viewModelScope.launch {
            repository.deleteProfile(profile)
        }
    }

    // Aim Trainer Controls
    fun startTrainer(
        gameMode: String = _aimState.value.gameMode,
        difficulty: String = _aimState.value.difficulty,
        distance: String = _aimState.value.distance
    ) {
        _aimState.value = AimTrainerState(
            isPlaying = true,
            isRoundComplete = false,
            gameMode = gameMode,
            difficulty = difficulty,
            distance = distance,
            roundDurationSeconds = 30,
            timeRemainingSeconds = 30
        )
    }

    fun stopTrainer() {
        _aimState.value = _aimState.value.copy(isPlaying = false)
    }

    fun registerShot(
        isHeadshot: Boolean,
        isBodyShot: Boolean,
        isOvershoot: Boolean,
        isUndershoot: Boolean,
        reactionTimeMs: Long,
        dragVelocity: Float
    ) {
        val current = _aimState.value
        if (!current.isPlaying) return

        val newTotal = current.totalShots + 1
        val newHeadshots = if (isHeadshot) current.headshots + 1 else current.headshots
        val newBody = if (isBodyShot) current.bodyShots + 1 else current.bodyShots
        val newMisses = if (!isHeadshot && !isBodyShot) current.misses + 1 else current.misses
        val newOvershoots = if (isOvershoot) current.overshoots + 1 else current.overshoots
        val newUndershoots = if (isUndershoot) current.undershoots + 1 else current.undershoots

        val speedRating = when {
            dragVelocity < 300f -> "TOO_SLOW"
            dragVelocity > 1400f -> "TOO_FAST"
            else -> "OPTIMAL"
        }

        val hitType = when {
            isHeadshot -> "HEADSHOT"
            isBodyShot -> "BODY"
            isOvershoot -> "OVERSHOOT"
            isUndershoot -> "UNDERSHOOT"
            else -> "MISS"
        }

        val damage = when {
            isHeadshot -> (380..520).random()
            isBodyShot -> (35..55).random()
            else -> 0
        }

        val feedback = when (hitType) {
            "HEADSHOT" -> "⚡ CRITICAL HEADSHOT! Perfect drag trajectory."
            "BODY" -> "Body Hit (Stuck on Chest). Drag faster upward!"
            "OVERSHOOT" -> "Overshot! Drag pulled too high above the head."
            "UNDERSHOOT" -> "Undershot! Drag stopped too low before neck."
            else -> "Missed Target! Keep crosshair closer before drag."
        }

        val reactions = current.reactionTimes + reactionTimeMs

        _aimState.value = current.copy(
            totalShots = newTotal,
            headshots = newHeadshots,
            bodyShots = newBody,
            misses = newMisses,
            overshoots = newOvershoots,
            undershoots = newUndershoots,
            currentReactionTimeMs = reactionTimeMs,
            reactionTimes = reactions,
            lastHitType = hitType,
            lastDamageValue = damage,
            dragSpeedRating = speedRating,
            feedbackMessage = feedback
        )
    }

    fun finishRound() {
        val current = _aimState.value
        if (!current.isPlaying && !current.isRoundComplete) return

        val avgReaction = if (current.reactionTimes.isNotEmpty()) {
            current.reactionTimes.average().toLong()
        } else 320L

        val hsPercent = if (current.totalShots > 0) {
            (current.headshots.toFloat() / current.totalShots) * 100f
        } else 0f

        val session = TrainingSession(
            gameMode = current.gameMode,
            difficulty = current.difficulty,
            targetDistance = current.distance,
            totalShots = current.totalShots,
            headshots = current.headshots,
            bodyShots = current.bodyShots,
            misses = current.misses,
            avgReactionTimeMs = avgReaction,
            overshoots = current.overshoots,
            undershoots = current.undershoots,
            dragSpeedRating = current.dragSpeedRating,
            headshotPercentage = hsPercent,
            improvementScore = ((hsPercent * 0.5f) + (350f - avgReaction.coerceIn(150, 450)) * 0.15f).toInt().coerceIn(10, 99)
        )

        viewModelScope.launch {
            repository.recordTrainingSession(session)
            refreshDiagnostics()
        }

        _aimState.value = current.copy(
            isPlaying = false,
            isRoundComplete = true
        )
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearTrainingHistory()
            refreshDiagnostics()
        }
    }
}
