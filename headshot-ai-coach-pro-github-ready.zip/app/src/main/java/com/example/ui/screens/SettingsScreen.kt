package com.example.ui.screens

import android.os.Build
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.CoachViewModel
import com.example.ui.components.GamingCard
import com.example.ui.components.LanguageToggle
import com.example.ui.components.NeonButton
import com.example.ui.components.SafetyBadge
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.HeadshotRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonOrange
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SettingsScreen(
    viewModel: CoachViewModel,
    modifier: Modifier = Modifier
) {
    val language by viewModel.language.collectAsState()
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(horizontal = 16.dp)
            .verticalScroll(scrollState)
    ) {
        Spacer(modifier = Modifier.height(14.dp))

        // Screen Header
        Text(
            text = "APP SETTINGS & SAFETY",
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp,
            color = NeonOrange
        )
        Text(
            text = if (language == "hi") "सुरक्षा नीति, डिवाइस जानकारी और भाषा" else "Companion integrity, hardware diagnostics & language",
            fontSize = 11.sp,
            color = TextSecondary
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Language Selection Card
        GamingCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = null,
                        tint = NeonOrange,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(text = "Application Language", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                        Text(text = "English / हिन्दी", color = TextSecondary, fontSize = 11.sp)
                    }
                }

                LanguageToggle(
                    currentLang = language,
                    onLangChanged = { viewModel.setLanguage(it) }
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Recalibrate / Reset Onboarding Wizard Card
        GamingCard {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Recalibrate Setup Wizard",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 13.sp
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Changed your phone model, screen refresh rate, or switched between 2-finger and claw?",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                NeonButton(
                    text = "Launch Calibration Wizard",
                    onClick = { viewModel.restartOnboarding() },
                    isPrimary = false,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "recalibrate_wizard_button"
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Device Hardware Diagnostics
        GamingCard {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PhoneAndroid,
                        contentDescription = null,
                        tint = NeonGold,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Device Hardware Profile",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                HardwareDetailRow("Manufacturer / Brand", Build.MANUFACTURER.replaceFirstChar { it.uppercase() })
                HardwareDetailRow("Device Model", Build.MODEL)
                HardwareDetailRow("Android OS Version", "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                HardwareDetailRow("Hardware Architecture", Build.HARDWARE)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Safe Android Companion Policy
        GamingCard(borderColor = NeonGreen) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = null,
                        tint = NeonGreen,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Safe Companion & Fair Play Guarantee",
                        fontWeight = FontWeight.ExtraBold,
                        color = NeonGreen,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "This application operates 100% independently outside of Free Fire and Free Fire MAX:",
                    fontSize = 11.sp,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(6.dp))

                PolicyBullet("• Zero Game Memory Access: Does not hook, modify, or read game memory.")
                PolicyBullet("• Zero Game File Alteration: Never modifies APKs, obb data, or game configuration files.")
                PolicyBullet("• No Aimbot / Cheats: Does not automate firing or simulate virtual touches in the game.")
                PolicyBullet("• Account Security: Does not collect, transmit, or ask for Free Fire credentials, UID, or tokens.")
                PolicyBullet("• No Dangerous Permissions: Requires no root access and no accessibility service permissions.")
                PolicyBullet("• Fair Play Notice: External muscle memory training and sensitivity calculations are 100% safe and compliant with developer guidelines.")
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Build APK Instructions for Android Phone Users
        GamingCard(borderColor = NeonCyan) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "How to Export APK on Your Phone",
                        fontWeight = FontWeight.Bold,
                        color = NeonCyan,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (language == "hi") listOf(
                        "1. AI Studio के ऊपरी दाएं कोने में 'Export' या 'Settings' मेनू पर टैप करें।",
                        "2. 'Download APK' या 'Download ZIP' विकल्प चुनें।",
                        "3. फोन पर डाउनलोड होने के बाद, APK पर टैप करें और 'Install' दबाएं।",
                        "4. यदि 'Unknown Sources' दिखे, तो अपने ब्राउज़र को इंस्टॉलेशन की अनुमति दें।"
                    ).joinToString("\n\n")
                    else listOf(
                        "1. Tap the Settings / Project menu at the top-right of your AI Studio browser window.",
                        "2. Select 'Download APK' or 'Export Project ZIP'.",
                        "3. Once the APK is generated and downloaded to your phone's Downloads folder, tap it to install.",
                        "4. If prompted with 'Install Unknown Apps', enable permission for your browser to complete installation."
                    ).joinToString("\n\n"),
                    fontSize = 11.sp,
                    color = TextSecondary,
                    lineHeight = 16.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun HardwareDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = TextMuted, fontSize = 11.sp)
        Text(text = value, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun PolicyBullet(text: String) {
    Text(
        text = text,
        color = TextSecondary,
        fontSize = 11.sp,
        modifier = Modifier.padding(vertical = 2.dp),
        lineHeight = 15.sp
    )
}
