package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppScreen
import com.example.ui.CoachViewModel
import com.example.ui.components.GamingCard
import com.example.ui.components.LanguageToggle
import com.example.ui.components.NeonButton
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.HeadshotRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonOrange
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun TrainingPlansScreen(
    viewModel: CoachViewModel,
    modifier: Modifier = Modifier
) {
    val language by viewModel.language.collectAsState()
    val scrollState = rememberScrollState()

    var selectedTab by remember { mutableStateOf("ROUTINES") } // "ROUTINES" or "TECHNIQUES"

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(horizontal = 16.dp)
            .verticalScroll(scrollState)
    ) {
        Spacer(modifier = Modifier.height(14.dp))

        // Screen Header with Language Toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "TRAINING ACADEMY",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    color = NeonOrange
                )
                Text(
                    text = if (language == "hi") "डेली ट्रेनिंग प्लान और हेडशॉट तकनीक" else "Daily routines & drag technique mastery",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }

            LanguageToggle(
                currentLang = language,
                onLangChanged = { viewModel.setLanguage(it) }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Switch between Routines & Techniques
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { selectedTab = "ROUTINES" }
                    .border(
                        BorderStroke(1.dp, if (selectedTab == "ROUTINES") NeonOrange else DarkSurfaceBorder),
                        RoundedCornerShape(10.dp)
                    ),
                color = if (selectedTab == "ROUTINES") NeonOrange.copy(alpha = 0.18f) else DarkSurface
            ) {
                Box(modifier = Modifier.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                    Text(
                        text = if (language == "hi") "दैनिक रूटीन" else "Daily Routines",
                        fontWeight = if (selectedTab == "ROUTINES") FontWeight.Bold else FontWeight.Medium,
                        color = if (selectedTab == "ROUTINES") NeonOrange else TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }

            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { selectedTab = "TECHNIQUES" }
                    .border(
                        BorderStroke(1.dp, if (selectedTab == "TECHNIQUES") NeonCyan else DarkSurfaceBorder),
                        RoundedCornerShape(10.dp)
                    ),
                color = if (selectedTab == "TECHNIQUES") NeonCyan.copy(alpha = 0.18f) else DarkSurface
            ) {
                Box(modifier = Modifier.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                    Text(
                        text = if (language == "hi") "हेडशॉट टेक्निक्स" else "Headshot Guides",
                        fontWeight = if (selectedTab == "TECHNIQUES") FontWeight.Bold else FontWeight.Medium,
                        color = if (selectedTab == "TECHNIQUES") NeonCyan else TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedTab == "ROUTINES") {
            // Plan 1: 5-Minute Fast Warmup
            RoutineCard(
                title = if (language == "hi") "5-मिनट क्विक वार्म-अप रूटीन" else "5-Minute Quick Warmup",
                duration = "5 Mins • Daily Starter",
                difficulty = "Beginner Friendly",
                color = NeonCyan,
                steps = if (language == "hi") listOf(
                    "1. सिमुलेटर में 20 क्लोज़-रेंज ड्रैग शॉट्स का अभ्यास करें।",
                    "2. J-ड्रैग कर्व पर ध्यान दें, जब तक कि लाल हेडशॉट न दिखे।",
                    "3. 10 रिएक्शन टेस्ट शॉट्स पूरा करें ताकि उंगलियां सक्रिय हों।"
                ) else listOf(
                    "1. Fire 20 close-range drag shots in the Aim Trainer.",
                    "2. Focus on smooth J-drag upward flick curvature.",
                    "3. Complete 10 quick reaction targets to activate finger agility."
                ),
                onLaunch = { viewModel.setScreen(AppScreen.AIM_TRAINER) }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Plan 2: 10-Minute One-Tap Mastery
            RoutineCard(
                title = if (language == "hi") "10-मिनट वन-टैप मास्टरी (M1887 & Deagle)" else "10-Minute One-Tap Mastery",
                duration = "10 Mins • Rusher & Shotgun",
                difficulty = "Intermediate",
                color = HeadshotRed,
                steps = if (language == "hi") listOf(
                    "1. फायर बटन साइज 45% रखें।",
                    "2. व्हाइट-टू-रेड नियम: क्रॉसहेयर को पहले कंधे के पास सफेद रखें, फिर तुरंत लाल होते ही ऊपर खींचें।",
                    "3. 25 मिड-रेंज वन-टैप फ्लिक पूरे करें।"
                ) else listOf(
                    "1. Calibrate Fire Button size to 45% for maximum upward travel.",
                    "2. Master the White-to-Red rule: keep crosshair near shoulder before flicking.",
                    "3. Drill 25 mid-range one-tap release flicks in the simulator."
                ),
                onLaunch = { viewModel.setScreen(AppScreen.AIM_TRAINER) }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Plan 3: 15-Minute Pro Esports Tournament Plan
            RoutineCard(
                title = if (language == "hi") "15-मिनट प्रो टूर्नामेंट ट्रैकिंग रूटीन" else "15-Minute Pro Tournament Routine",
                duration = "15 Mins • Competitive Claw",
                difficulty = "Advanced Pro",
                color = NeonGold,
                steps = if (language == "hi") listOf(
                    "1. एडवांस्ड मूविंग टारगेट मोड चुनें (स्ट्रैफिंग दुश्मन)।",
                    "2. पहले 30 सेकंड केवल दुश्मन की गति को ट्रैक करें, फिर ड्रैग करें।",
                    "3. क्लोज़-रेंज और लॉन्ग-रेंज के बीच जल्दी स्विच करने का अभ्यास करें।"
                ) else listOf(
                    "1. Select Advanced moving target strafing in the Aim Trainer.",
                    "2. Track moving target across screen for 0.3s before initiating drag.",
                    "3. Alternate between Close-range J-drag and Long-range micro tap."
                ),
                onLaunch = { viewModel.setScreen(AppScreen.AIM_TRAINER) }
            )
        } else {
            // Technique Guides
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                TechniqueGuideCard(
                    title = if (language == "hi") "1. स्ट्रेट वर्टिकल ड्रैग (Straight Drag)" else "1. Straight Vertical Drag",
                    suitableFor = "Mid-Range • Stationary or charging enemies",
                    summary = if (language == "hi")
                        "जब दुश्मन सीधे आपकी ओर दौड़ रहा हो या स्थिर खड़ा हो, तो क्रॉसहेयर को छाती के मध्य में रखें और फायर बटन को बिना झुकाए सीधा ऊपर की ओर खींचें। यदि गोली सिर के ऊपर निकलती है, तो ड्रैग थोड़ा धीमा करें।"
                    else
                        "Best when enemies are standing or sprinting directly toward you. Lock crosshair at enemy chest, then swipe fire button straight up in a clean vertical line. If you overshoot, decrease drag stroke speed.",
                    language = language
                )

                TechniqueGuideCard(
                    title = if (language == "hi") "2. रोटेशन ड्रैग / J-ड्रैग (Rotation J-Drag)" else "2. Rotation J-Drag Technique",
                    suitableFor = "Close-Range • Enemies sprinting left/right",
                    summary = if (language == "hi")
                        "जब दुश्मन दाईं या बाईं तरफ तेजी से भाग रहा हो, तो सीधा ड्रैग काम नहीं करेगा। फायर बटन को नीचे से शुरू करके एक 'J' की तरह घुमाते हुए दुश्मन के सिर की दिशा में ऊपर ले जाएं।"
                    else
                        "Essential for close-range combat when enemies are strafing laterally. Start your fire button gesture with a slight downward dip and curve upward in a 'J' shape matching the direction enemy is running.",
                    language = language
                )

                TechniqueGuideCard(
                    title = if (language == "hi") "3. व्हाइट-टू-रेड क्रॉसहेयर नियम" else "3. White-to-Red Crosshair Placement",
                    suitableFor = "All Ranges • Aim-Assist Drag Trigger",
                    summary = if (language == "hi")
                        "फ्री फायर में डिफॉल्ट एम-असिस्ट बहुत मजबूत होता है। यदि क्रॉसहेयर पहले से ही दुश्मन की छाती पर लाल है, तो वह वहीं लॉक हो जाता है। इसलिए क्रॉसहेयर को दुश्मन के कंधे के थोड़ा बगल में सफेद रखें, और ड्रैग करते ही जब वह लाल हो, तो वह तुरंत सिर पर खिंच जाता है।"
                    else
                        "In Free Fire, default aim assist locks hard to the chest if crosshair is already red before firing. Keep your crosshair slightly off the enemy body (white), and flick upward into the head so the red lock snaps directly to the helmet.",
                    language = language
                )

                TechniqueGuideCard(
                    title = if (language == "hi") "4. फायर बटन साइज और प्लेसमेंट सीक्रेट" else "4. Fire Button Size & Placement",
                    suitableFor = "HUD Optimization • Ergonomics",
                    summary = if (language == "hi")
                        "फायर बटन का आकार 45% से 50% के बीच रखें। इसे स्क्रीन के निचले-दाएं कोने में रखें ताकि आपके अंगूठे को ऊपर की ओर ड्रैग करने के लिए ज्यादा स्क्रीन स्पेस मिले।"
                    else
                        "Keep Fire Button between 45% and 50% size. Position it slightly lower in your custom HUD so your right thumb has maximum upward vertical runway to execute full drag flicks.",
                    language = language
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun RoutineCard(
    title: String,
    duration: String,
    difficulty: String,
    color: Color,
    steps: List<String>,
    onLaunch: () -> Unit
) {
    GamingCard(borderColor = color) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, fontWeight = FontWeight.ExtraBold, color = color, fontSize = 14.sp)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(color.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(text = difficulty, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }

            Text(text = duration, color = TextMuted, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(10.dp))

            steps.forEach { step ->
                Text(text = step, color = TextPrimary, fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp))
            }

            Spacer(modifier = Modifier.height(12.dp))
            NeonButton(
                text = "▶ Start Drill in Simulator",
                onClick = onLaunch,
                modifier = Modifier.fillMaxWidth(),
                testTag = "routine_start_btn"
            )
        }
    }
}

@Composable
private fun TechniqueGuideCard(
    title: String,
    suitableFor: String,
    summary: String,
    language: String
) {
    var expanded by remember { mutableStateOf(false) }

    GamingCard(onClick = { expanded = !expanded }) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = title, fontWeight = FontWeight.Bold, color = NeonOrange, fontSize = 14.sp)
                    Text(text = suitableFor, color = NeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }
                Icon(
                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = NeonOrange
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 10.dp)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkSurfaceElevated)
                            .padding(10.dp)
                    ) {
                        Text(text = summary, color = TextPrimary, fontSize = 12.sp, lineHeight = 18.sp)
                    }
                }
            }
        }
    }
}
