package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppScreen
import com.example.ui.CoachViewModel
import com.example.ui.components.GamingCard
import com.example.ui.components.LanguageToggle
import com.example.ui.components.NeonButton
import com.example.ui.components.SafetyBadge
import com.example.ui.components.StatBadge
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.HeadshotRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonOrange
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HomeScreen(
    viewModel: CoachViewModel,
    modifier: Modifier = Modifier
) {
    val defaultProfile by viewModel.defaultProfile.collectAsState()
    val improvementScore by viewModel.headshotImprovementScore.collectAsState()
    val aiInsight by viewModel.aiInsight.collectAsState()
    val language by viewModel.language.collectAsState()
    val allSessions by viewModel.allSessions.collectAsState()

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(horizontal = 16.dp)
            .verticalScroll(scrollState)
    ) {
        Spacer(modifier = Modifier.height(14.dp))

        // App Header: Title & Language Switcher
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "HEADSHOT AI COACH",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    color = NeonOrange
                )
                Text(
                    text = if (language == "hi") "फ्री फायर हेडशॉट और सेंसिटिविटी ट्रेनर" else "Free Fire & MAX Aim Companion",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }

            LanguageToggle(
                currentLang = language,
                onLangChanged = { viewModel.setLanguage(it) }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))
        SafetyBadge()
        Spacer(modifier = Modifier.height(16.dp))

        // Hero: Headshot Improvement Score Ring Card
        GamingCard(
            borderColor = NeonOrange,
            glowColor = NeonOrange.copy(alpha = 0.25f),
            onClick = { viewModel.setScreen(AppScreen.ANALYTICS) }
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (language == "hi") "हेडशॉट इम्प्रूवमेंट स्कोर" else "HEADSHOT IMPROVEMENT SCORE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonOrange,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (improvementScore > 0) "$improvementScore/100" else "--/100",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (allSessions.isEmpty())
                            (if (language == "hi") "ट्रेनिंग शुरू करें अपना स्कोर जानने के लिए" else "Train in simulator to calibrate score")
                        else
                            "${allSessions.size} training sessions recorded",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }

                // Animated Circular Gauge
                Box(
                    modifier = Modifier.size(80.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val animatedScore by animateFloatAsState(
                        targetValue = improvementScore.toFloat(),
                        animationSpec = tween(durationMillis = 1000),
                        label = "scoreRing"
                    )

                    Canvas(modifier = Modifier.size(80.dp)) {
                        val stroke = 8.dp.toPx()
                        // Track
                        drawCircle(
                            color = DarkSurfaceBorder,
                            radius = (size.minDimension - stroke) / 2f,
                            style = Stroke(stroke)
                        )
                        // Progress
                        val sweep = (animatedScore / 100f) * 360f
                        drawArc(
                            brush = Brush.sweepGradient(listOf(NeonOrange, NeonCyan, HeadshotRed, NeonOrange)),
                            startAngle = -90f,
                            sweepAngle = sweep,
                            useCenter = false,
                            style = Stroke(stroke, cap = StrokeCap.Round)
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.Timeline,
                        contentDescription = null,
                        tint = NeonOrange,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // AI Coach Diagnosis Banner
        GamingCard(
            borderColor = when (aiInsight.severity) {
                "SUCCESS" -> NeonGreen
                "WARNING" -> NeonOrange
                else -> NeonCyan
            }
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.FlashOn,
                        contentDescription = null,
                        tint = when (aiInsight.severity) {
                            "SUCCESS" -> NeonGreen
                            "WARNING" -> NeonOrange
                            else -> NeonCyan
                        },
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "AI COACH DIAGNOSIS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = when (aiInsight.severity) {
                            "SUCCESS" -> NeonGreen
                            "WARNING" -> NeonOrange
                            else -> NeonCyan
                        }
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = aiInsight.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = aiInsight.recommendation,
                    fontSize = 12.sp,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkSurfaceElevated)
                        .padding(8.dp)
                ) {
                    Text(
                        text = "💡 ${aiInsight.sensitivityAdjustmentTip}",
                        fontSize = 11.sp,
                        color = NeonCyan,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Big Primary CTA: Launch Aim Trainer Simulator
        NeonButton(
            text = if (language == "hi") "🎯 एम ट्रेनर सिमुलेटर शुरू करें" else "🎯 Launch Aim Trainer Simulator",
            onClick = { viewModel.setScreen(AppScreen.AIM_TRAINER) },
            modifier = Modifier.fillMaxWidth(),
            testTag = "home_launch_aim_trainer"
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Active Sensitivity Quick Look Card
        val activeProfile = defaultProfile
        if (activeProfile != null) {
            GamingCard(
                onClick = { viewModel.setScreen(AppScreen.SENSITIVITY) }
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "ACTIVE SENSITIVITY PROFILE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeonOrange
                            )
                            Text(
                                text = activeProfile.profileName,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Tune",
                            tint = NeonCyan
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatBadge("General", "${activeProfile.generalSens}", NeonOrange, Modifier.weight(1f))
                        StatBadge("Red Dot", "${activeProfile.redDotSens}", NeonCyan, Modifier.weight(1f))
                        StatBadge("2x Scope", "${activeProfile.scope2xSens}", NeonGold, Modifier.weight(1f))
                        StatBadge("Fire Btn", "${activeProfile.fireButtonSize}%", NeonGreen, Modifier.weight(1f))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Daily Headshot Routine Checklist
        DailyPracticeWidget(language = language, onStartRoutine = { viewModel.setScreen(AppScreen.AIM_TRAINER) })

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun DailyPracticeWidget(
    language: String,
    onStartRoutine: () -> Unit
) {
    var step1Done by remember { mutableStateOf(false) }
    var step2Done by remember { mutableStateOf(false) }
    var step3Done by remember { mutableStateOf(false) }

    GamingCard {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.FitnessCenter,
                        contentDescription = null,
                        tint = NeonOrange,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (language == "hi") "दैनिक हेडशॉट रूटीन" else "DAILY HEADSHOT ROUTINE",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonOrange
                    )
                }
                Text(
                    text = "10 Mins Total",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            RoutineTaskItem(
                title = if (language == "hi") "1. वार्म-अप: 15 क्लोज़ रेंज ड्रैग शॉट" else "1. Warm-up: 15 Close-Range Drag Shots",
                subtitle = "Practise J-Drag upward flick velocity",
                isDone = step1Done,
                onToggle = { step1Done = !step1Done }
            )
            RoutineTaskItem(
                title = if (language == "hi") "2. मिड-रेंज स्ट्रेट वर्टिकल ड्रैग (15 शॉट्स)" else "2. Mid-Range Vertical Drag (15 Shots)",
                subtitle = "Aim assist chest-to-head lift precision",
                isDone = step2Done,
                onToggle = { step2Done = !step2Done }
            )
            RoutineTaskItem(
                title = if (language == "hi") "3. मूविंग टारगेट ट्रैकिंग ड्रिल" else "3. Moving Target Tracking Drill",
                subtitle = "Follow horizontal strafe before flicking",
                isDone = step3Done,
                onToggle = { step3Done = !step3Done }
            )

            Spacer(modifier = Modifier.height(10.dp))
            NeonButton(
                text = "Start Today's Routine →",
                onClick = onStartRoutine,
                isPrimary = false,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun RoutineTaskItem(
    title: String,
    subtitle: String,
    isDone: Boolean,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggle() }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (isDone) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
            contentDescription = null,
            tint = if (isDone) NeonGreen else TextMuted,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (isDone) TextMuted else TextPrimary
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }
    }
}
