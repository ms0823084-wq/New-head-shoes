package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TrainingSession
import com.example.ui.AppScreen
import com.example.ui.CoachViewModel
import com.example.ui.components.GamingCard
import com.example.ui.components.NeonButton
import com.example.ui.components.StatBadge
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.HeadshotRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonOrange
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun AnalyticsScreen(
    viewModel: CoachViewModel,
    modifier: Modifier = Modifier
) {
    val allSessions by viewModel.allSessions.collectAsState()
    val improvementScore by viewModel.headshotImprovementScore.collectAsState()
    val beforeAfter by viewModel.beforeAfter.collectAsState()
    val aiInsight by viewModel.aiInsight.collectAsState()
    val language by viewModel.language.collectAsState()

    var showClearHistoryDialog by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    // Aggregate statistics from player's recorded sessions
    val totalShots = allSessions.sumOf { it.totalShots }
    val totalHeadshots = allSessions.sumOf { it.headshots }
    val totalOvershoots = allSessions.sumOf { it.overshoots }
    val totalUndershoots = allSessions.sumOf { it.undershoots }
    val avgReaction = if (allSessions.isNotEmpty()) {
        allSessions.map { it.avgReactionTimeMs }.average().roundToInt()
    } else 0
    val avgHeadshotRate = if (totalShots > 0) {
        ((totalHeadshots.toFloat() / totalShots) * 100f).roundToInt()
    } else 0

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(horizontal = 16.dp)
            .verticalScroll(scrollState)
    ) {
        Spacer(modifier = Modifier.height(14.dp))

        // Screen Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "PERFORMANCE ANALYTICS",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    color = NeonOrange
                )
                Text(
                    text = if (language == "hi") "व्यक्तिगत हेडशॉट ट्रैकिंग और परिणाम" else "Data-driven aim mechanics evaluation",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }

            if (allSessions.isNotEmpty()) {
                IconButton(onClick = { showClearHistoryDialog = true }) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Clear History",
                        tint = TextMuted
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Before & After Progress Card
        GamingCard(borderColor = NeonCyan) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "BEFORE VS CURRENT PROGRESS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonCyan
                    )
                    Text(
                        text = "${allSessions.size} Sessions Recorded",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                val comparison = beforeAfter
                if (comparison != null && allSessions.size >= 2) {
                    val (baseline, current) = comparison
                    val diff = current - baseline
                    val diffColor = if (diff >= 0) NeonGreen else HeadshotRed

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        ScoreComparisonPill("Earliest Baseline", "$baseline/100", TextSecondary)

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = if (diff >= 0) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                contentDescription = null,
                                tint = diffColor,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "${if (diff >= 0) "+" else ""}$diff pts",
                                color = diffColor,
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp
                            )
                        }

                        ScoreComparisonPill("Current Score", "$current/100", NeonOrange)
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkSurfaceElevated)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = if (language == "hi")
                                "प्रगति की तुलना देखने के लिए कम से कम 2 अलग-अलग ट्रेनिंग सेशन पूरे करें।"
                            else
                                "Complete at least 2 training sessions to generate a before-and-after baseline comparison from your own data.",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Aggregate Metrics Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatBadge("Headshot Rate", "$avgHeadshotRate%", HeadshotRed, Modifier.weight(1f))
            StatBadge("Avg Reaction", "${avgReaction}ms", NeonCyan, Modifier.weight(1f))
            StatBadge("Total Shots", "$totalShots", NeonGold, Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Drag Trajectory Diagnostics: Overshoots vs Undershoots
        GamingCard {
            Column {
                Text(
                    text = "DRAG ERROR DIAGNOSTIC BREAKDOWN",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Identifies whether your sensitivity is pulling too high or sticking on chest.",
                    fontSize = 11.sp,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(12.dp))

                val safeTotal = totalShots.coerceAtLeast(1).toFloat()
                val headshotPct = (totalHeadshots.toFloat() / safeTotal) * 100f
                val overshootPct = (totalOvershoots.toFloat() / safeTotal) * 100f
                val undershootPct = (totalUndershoots.toFloat() / safeTotal) * 100f

                // Stacked Bar Graphic
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(20.dp)
                        .clip(RoundedCornerShape(6.dp))
                ) {
                    if (headshotPct > 0) {
                        Box(
                            modifier = Modifier
                                .weight(headshotPct.coerceAtLeast(1f))
                                .fillMaxSize()
                                .background(HeadshotRed)
                        )
                    }
                    if (undershootPct > 0) {
                        Box(
                            modifier = Modifier
                                .weight(undershootPct.coerceAtLeast(1f))
                                .fillMaxSize()
                                .background(NeonGold)
                        )
                    }
                    if (overshootPct > 0) {
                        Box(
                            modifier = Modifier
                                .weight(overshootPct.coerceAtLeast(1f))
                                .fillMaxSize()
                                .background(NeonOrange)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Legend
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    DiagnosticLegendItem("Headshots", "${headshotPct.roundToInt()}%", HeadshotRed)
                    DiagnosticLegendItem("Undershoots", "${undershootPct.roundToInt()}%", NeonGold)
                    DiagnosticLegendItem("Overshoots", "${overshootPct.roundToInt()}%", NeonOrange)
                }

                Spacer(modifier = Modifier.height(10.dp))

                // AI Coach adjustment tip for current tendency
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkSurfaceElevated)
                        .padding(10.dp)
                ) {
                    Text(
                        text = when {
                            overshootPct > 35f ->
                                "⚠️ High Overshoot Ratio: Crosshair is flying above target heads. Your General sensitivity is likely too high. Reduce by 3-5 points."
                            undershootPct > 35f ->
                                "⚠️ High Undershoot Ratio: Crosshair is sticking to the torso. Increase General sensitivity by 4 points or shrink your Fire Button."
                            else ->
                                "✅ Balanced Drag Trajectory: Your muscle memory has calibrated well to your screen touch sample rate."
                        },
                        fontSize = 11.sp,
                        color = TextPrimary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Important Simulator Disclaimers
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .border(BorderStroke(1.dp, DarkSurfaceBorder), RoundedCornerShape(12.dp)),
            color = DarkSurfaceElevated.copy(alpha = 0.6f)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Honest Training Note: Simulator accuracy measures your touch reaction, upward flick velocity, and muscle memory discipline. Real in-game matches involve weapon recoil patterns, enemy gloo walls, character skills, and network ping. This app does not promise or guarantee arbitrary headshot percentages; improvement comes through consistent muscle memory drill.",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    lineHeight = 15.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Session History Log
        GamingCard {
            Column {
                Text(
                    text = "RECORDED SESSION HISTORY",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonOrange
                )
                Spacer(modifier = Modifier.height(10.dp))

                if (allSessions.isEmpty()) {
                    Text(
                        text = "No recorded sessions yet. Practice in the Aim Trainer simulator to start recording logs.",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                } else {
                    allSessions.take(8).forEach { session ->
                        SessionHistoryRow(session)
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }

    // Clear history confirmation dialog
    if (showClearHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showClearHistoryDialog = false },
            containerColor = DarkSurface,
            shape = RoundedCornerShape(16.dp),
            title = {
                Text("Clear Training History?", color = TextPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    "This will delete all recorded training sessions and reset your baseline progress.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearHistory()
                        showClearHistoryDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HeadshotRed)
                ) {
                    Text("Delete All", color = Color.White)
                }
            },
            dismissButton = {
                Button(
                    onClick = { showClearHistoryDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated)
                ) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun ScoreComparisonPill(
    label: String,
    value: String,
    accentColor: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, fontSize = 20.sp, fontWeight = FontWeight.Black, color = accentColor)
        Text(text = label, fontSize = 10.sp, color = TextSecondary)
    }
}

@Composable
private fun DiagnosticLegendItem(
    label: String,
    value: String,
    color: Color
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = "$label: $value", fontSize = 11.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun SessionHistoryRow(session: TrainingSession) {
    val dateFormat = remember { SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()) }
    val timeStr = remember(session.timestamp) { dateFormat.format(Date(session.timestamp)) }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp)),
        color = DarkSurfaceElevated
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "${session.gameMode.replace("_", " ")} (${session.targetDistance})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "$timeStr • Reaction: ${session.avgReactionTimeMs}ms",
                    fontSize = 10.sp,
                    color = TextMuted
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${session.headshotPercentage.roundToInt()}% HS",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = HeadshotRed
                )
                Text(
                    text = "${session.headshots}/${session.totalShots} Hits",
                    fontSize = 10.sp,
                    color = TextSecondary
                )
            }
        }
    }
}
