package com.example.data

import android.os.Build
import com.example.ai.HeadshotCoachEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext

class CoachRepository(
    private val profileDao: SensitivityProfileDao,
    private val sessionDao: TrainingSessionDao
) {
    val allProfiles: Flow<List<SensitivityProfile>> = profileDao.getAllProfiles()
    val defaultProfile: Flow<SensitivityProfile?> = profileDao.getDefaultProfile()
    val allSessions: Flow<List<TrainingSession>> = sessionDao.getAllSessions()
    val recentSessions: Flow<List<TrainingSession>> = sessionDao.getRecentSessions(10)

    suspend fun initializeDefaultsIfNeeded() = withContext(Dispatchers.IO) {
        val count = profileDao.getProfileCount()
        if (count == 0) {
            val phone = "${Build.MANUFACTURER} ${Build.MODEL}"
            // Default 1: Competitive All-Rounder (MAX)
            val profile1 = HeadshotCoachEngine.generateSensitivity(
                gameVersion = "Free Fire MAX",
                phoneModel = phone,
                fpsSetting = "High 60 FPS",
                refreshRateHz = 90,
                fingerLayout = "2-Finger",
                playstyle = "All-Rounder"
            ).copy(isDefault = true, profileName = "Default Competitive Pro (MAX)")
            profileDao.insertProfile(profile1)

            // Default 2: One-Tap Shotgun Rusher
            val profile2 = HeadshotCoachEngine.generateSensitivity(
                gameVersion = "Free Fire",
                phoneModel = phone,
                fpsSetting = "Ultra 90/120 FPS",
                refreshRateHz = 120,
                fingerLayout = "3-Finger Claw",
                playstyle = "One-Tap / Rusher"
            ).copy(isDefault = false, profileName = "M1887 One-Tap Rusher")
            profileDao.insertProfile(profile2)

            // Default 3: 4-Finger Tournament Claw
            val profile3 = HeadshotCoachEngine.generateSensitivity(
                gameVersion = "Free Fire MAX",
                phoneModel = phone,
                fpsSetting = "Ultra 90/120 FPS",
                refreshRateHz = 120,
                fingerLayout = "4-Finger Claw",
                playstyle = "All-Rounder"
            ).copy(isDefault = false, profileName = "4-Finger Tournament Claw")
            profileDao.insertProfile(profile3)
        }
    }

    suspend fun saveProfile(profile: SensitivityProfile): Long = withContext(Dispatchers.IO) {
        if (profile.isDefault) {
            profileDao.clearDefaultFlags()
        }
        profileDao.insertProfile(profile)
    }

    suspend fun updateProfile(profile: SensitivityProfile) = withContext(Dispatchers.IO) {
        profileDao.updateProfile(profile)
    }

    suspend fun deleteProfile(profile: SensitivityProfile) = withContext(Dispatchers.IO) {
        profileDao.deleteProfile(profile)
    }

    suspend fun setDefaultProfile(id: Long) = withContext(Dispatchers.IO) {
        profileDao.clearDefaultFlags()
        profileDao.setDefaultProfile(id)
    }

    suspend fun recordTrainingSession(session: TrainingSession): Long = withContext(Dispatchers.IO) {
        sessionDao.insertSession(session)
    }

    suspend fun clearTrainingHistory() = withContext(Dispatchers.IO) {
        sessionDao.clearAllSessions()
    }

    suspend fun getBeforeAfterComparison(): Pair<Int, Int>? = withContext(Dispatchers.IO) {
        val earliest = sessionDao.getEarliestSessions()
        val latest = sessionDao.getLatestSessions()
        HeadshotCoachEngine.calculateBeforeAfter(earliest, latest)
    }

    suspend fun getAiCoachInsight(): AiCoachInsight = withContext(Dispatchers.IO) {
        val recent = sessionDao.getLatestSessions()
        val active = profileDao.getDefaultProfile().firstOrNull()
        HeadshotCoachEngine.analyzeSessions(recent, active)
    }
}
