package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SensitivityProfileDao {
    @Query("SELECT * FROM sensitivity_profiles ORDER BY isDefault DESC, createdAt DESC")
    fun getAllProfiles(): Flow<List<SensitivityProfile>>

    @Query("SELECT * FROM sensitivity_profiles WHERE isDefault = 1 LIMIT 1")
    fun getDefaultProfile(): Flow<SensitivityProfile?>

    @Query("SELECT * FROM sensitivity_profiles WHERE id = :id LIMIT 1")
    suspend fun getProfileById(id: Long): SensitivityProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: SensitivityProfile): Long

    @Update
    suspend fun updateProfile(profile: SensitivityProfile)

    @Delete
    suspend fun deleteProfile(profile: SensitivityProfile)

    @Query("UPDATE sensitivity_profiles SET isDefault = 0")
    suspend fun clearDefaultFlags()

    @Query("UPDATE sensitivity_profiles SET isDefault = 1 WHERE id = :id")
    suspend fun setDefaultProfile(id: Long)

    @Query("SELECT COUNT(*) FROM sensitivity_profiles")
    suspend fun getProfileCount(): Int
}

@Dao
interface TrainingSessionDao {
    @Query("SELECT * FROM training_sessions ORDER BY timestamp DESC")
    fun getAllSessions(): Flow<List<TrainingSession>>

    @Query("SELECT * FROM training_sessions ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentSessions(limit: Int): Flow<List<TrainingSession>>

    @Query("SELECT * FROM training_sessions ORDER BY timestamp ASC LIMIT 5")
    suspend fun getEarliestSessions(): List<TrainingSession>

    @Query("SELECT * FROM training_sessions ORDER BY timestamp DESC LIMIT 5")
    suspend fun getLatestSessions(): List<TrainingSession>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: TrainingSession): Long

    @Query("DELETE FROM training_sessions")
    suspend fun clearAllSessions()

    @Query("SELECT COUNT(*) FROM training_sessions")
    suspend fun getSessionCount(): Int
}
