package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sensitivity_profiles")
data class SensitivityProfile(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val profileName: String,
    val gameVersion: String, // "Free Fire" or "Free Fire MAX"
    val phoneModel: String,
    val fpsSetting: String, // "Normal 30 FPS", "High 60 FPS", "Ultra 90/120 FPS"
    val refreshRateHz: Int, // 60, 90, 120, 144
    val fingerLayout: String, // "2-Finger", "3-Finger Claw", "4-Finger Claw"
    val generalSens: Int, // 0 - 100
    val redDotSens: Int,
    val scope2xSens: Int,
    val scope4xSens: Int,
    val sniperSens: Int,
    val freeLookSens: Int,
    val fireButtonSize: Int, // e.g. 48%
    val fireButtonPosition: String, // e.g. "Low-Right Drag Zone"
    val dpiRecommendation: Int, // e.g. 420
    val playstyle: String = "All-Rounder", // "All-Rounder", "One-Tap / Rusher", "Sniper"
    val isDefault: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "training_sessions")
data class TrainingSession(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val gameMode: String, // "DRAG_AIM", "ONE_TAP", "REACTION_TIME", "CROSSHAIR_PLACEMENT"
    val difficulty: String, // "BEGINNER", "INTERMEDIATE", "ADVANCED"
    val targetDistance: String, // "CLOSE", "MID", "LONG"
    val totalShots: Int,
    val headshots: Int,
    val bodyShots: Int,
    val misses: Int,
    val avgReactionTimeMs: Long,
    val overshoots: Int,
    val undershoots: Int,
    val dragSpeedRating: String, // "TOO_SLOW", "OPTIMAL", "TOO_FAST"
    val headshotPercentage: Float,
    val improvementScore: Int
)

data class AiCoachInsight(
    val title: String,
    val subtitle: String,
    val recommendation: String,
    val sensitivityAdjustmentTip: String,
    val suggestedDrill: String,
    val severity: String // "SUCCESS", "WARNING", "INFO"
)
