package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppScreen
import com.example.ui.CoachViewModel
import com.example.ui.screens.AimTrainerScreen
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.SensitivityScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TrainingPlansScreen
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonOrange
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {

    private val viewModel: CoachViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val hasCompletedOnboarding by viewModel.hasCompletedOnboarding.collectAsState()
                val currentScreen by viewModel.currentScreen.collectAsState()

                if (!hasCompletedOnboarding) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(DarkBg)
                            .windowInsetsPadding(WindowInsets.safeDrawing)
                    ) {
                        OnboardingScreen(viewModel = viewModel)
                    }
                } else {
                    // Back handler for secondary screens to return to Home
                    BackHandler(enabled = currentScreen != AppScreen.HOME) {
                        viewModel.setScreen(AppScreen.HOME)
                    }

                    Scaffold(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(DarkBg),
                        contentWindowInsets = WindowInsets.safeDrawing,
                        bottomBar = {
                            CoachBottomNavigationBar(
                                currentScreen = currentScreen,
                                onSelectScreen = { viewModel.setScreen(it) }
                            )
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(DarkBg)
                                .padding(innerPadding)
                        ) {
                            Crossfade(targetState = currentScreen, label = "screenTransition") { screen ->
                                when (screen) {
                                    AppScreen.HOME -> HomeScreen(viewModel = viewModel)
                                    AppScreen.SENSITIVITY -> SensitivityScreen(viewModel = viewModel)
                                    AppScreen.AIM_TRAINER -> AimTrainerScreen(viewModel = viewModel)
                                    AppScreen.ANALYTICS -> AnalyticsScreen(viewModel = viewModel)
                                    AppScreen.TRAINING_PLANS -> TrainingPlansScreen(viewModel = viewModel)
                                    AppScreen.SETTINGS -> SettingsScreen(viewModel = viewModel)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

data class NavItem(
    val screen: AppScreen,
    val label: String,
    val icon: ImageVector,
    val testTag: String
)

@Composable
fun CoachBottomNavigationBar(
    currentScreen: AppScreen,
    onSelectScreen: (AppScreen) -> Unit
) {
    val items = listOf(
        NavItem(AppScreen.HOME, "Home", Icons.Default.Home, "nav_home"),
        NavItem(AppScreen.SENSITIVITY, "Sens", Icons.Default.Tune, "nav_sens"),
        NavItem(AppScreen.AIM_TRAINER, "Trainer", Icons.Default.SportsEsports, "nav_trainer"),
        NavItem(AppScreen.ANALYTICS, "Stats", Icons.Default.Timeline, "nav_stats"),
        NavItem(AppScreen.TRAINING_PLANS, "Plans", Icons.Default.FitnessCenter, "nav_plans"),
        NavItem(AppScreen.SETTINGS, "Settings", Icons.Default.Settings, "nav_settings")
    )

    NavigationBar(
        modifier = Modifier
            .background(DarkSurfaceElevated)
            .windowInsetsPadding(WindowInsets.navigationBars),
        containerColor = DarkSurfaceElevated,
        tonalElevation = 6.dp
    ) {
        items.forEach { item ->
            val isSelected = currentScreen == item.screen
            NavigationBarItem(
                selected = isSelected,
                onClick = { onSelectScreen(item.screen) },
                icon = {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.label,
                        tint = if (isSelected) Color.Black else TextSecondary
                    )
                },
                label = {
                    Text(
                        text = item.label,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) NeonOrange else TextMuted
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = NeonOrange,
                    selectedIconColor = Color.Black,
                    unselectedIconColor = TextSecondary,
                    selectedTextColor = NeonOrange,
                    unselectedTextColor = TextMuted
                ),
                modifier = Modifier.testTag(item.testTag)
            )
        }
    }
}
