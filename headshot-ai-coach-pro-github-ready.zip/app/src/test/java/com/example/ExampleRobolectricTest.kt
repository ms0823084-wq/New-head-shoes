package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ai.HeadshotCoachEngine
import com.example.data.TrainingSession
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun readStringFromContext() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Headshot Coach Pro", appName)
    }

    @Test
    fun testHeadshotCoachSensitivityGeneration() {
        val profile = HeadshotCoachEngine.generateSensitivity(
            gameVersion = "Free Fire MAX",
            phoneModel = "Pixel 8 Pro",
            fpsSetting = "Ultra 90/120 FPS",
            refreshRateHz = 120,
            fingerLayout = "2-Finger",
            playstyle = "One-Tap / Rusher"
        )
        assertNotNull(profile)
        assertTrue(profile.generalSens in 85..100)
        assertTrue(profile.redDotSens in 75..100)
        assertTrue(profile.fireButtonSize in 40..60)
    }

    @Test
    fun testHeadshotImprovementScoreCalculation() {
        val sessions = listOf(
            TrainingSession(
                gameMode = "DRAG_AIM",
                difficulty = "INTERMEDIATE",
                targetDistance = "MID",
                totalShots = 20,
                headshots = 15,
                bodyShots = 4,
                misses = 1,
                avgReactionTimeMs = 210,
                overshoots = 2,
                undershoots = 1,
                dragSpeedRating = "OPTIMAL",
                headshotPercentage = 75.0f,
                improvementScore = 80
            )
        )
        val score = HeadshotCoachEngine.calculateScore(sessions)
        assertTrue("Score should be between 50 and 99 for high performance", score >= 50)
    }
}
