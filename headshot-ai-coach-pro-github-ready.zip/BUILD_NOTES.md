# Package changes

- Added a GitHub Actions workflow for building a debug APK and uploading it as an artifact.
- Updated the README with phone-friendly GitHub Actions steps and limits.
- Removed custom debug/release signing references that depended on missing keystore files or secrets.
- The project has not been built or tested in this environment. Run the GitHub Actions workflow and inspect the build logs before trusting the APK.
